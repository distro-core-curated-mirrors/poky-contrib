:py:mod:`simplemediawiki` --- Extremely low-level wrapper to the MediaWiki API
==============================================================================

.. automodule:: simplemediawiki
   :synopsis: Basic wrapper to MediaWiki API

Module reference
----------------
.. autoclass:: simplemediawiki.MediaWiki
   :members:

.. autofunction:: simplemediawiki.build_user_agent
