#!/usr/bin/python

from __future__ import division
import sys
import time
from time import gmtime, strftime
import datetime
import subprocess
import os
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

def is_ab_busy():
    nr_proc = subprocess.check_output("sudo ssh root@10.237.112.85 \"ps -ef | grep bitbake | grep -v grep | wc -l\"", shell=True)
    if str(nr_proc).strip() != "0":
        return True
    else:
        return False

if not is_ab_busy():
    print "AB is not busy"
else:
    print "Ab is busy"