#!/usr/bin/env python

from simplemediawiki import MediaWiki
import os, sys, re
import datetime
from testopia import Testopia
from difflib import SequenceMatcher as SM

def get_workweek():
    now = datetime.datetime.now()
    return datetime.date(now.year, now.month, now.day).isocalendar()[1]

try:
    branch = str(sys.argv[1]).strip()
    poky_version = str(sys.argv[2]).strip()
    poky_commit = str(sys.argv[3]).strip()
    ab_link = str(sys.argv[4]).strip()
    date = str(sys.argv[5]).strip()
except IndexError, NameError:
    print "Usage: ./update_wiki.py <branch> <version> <commit> <download_link> <date>"
    print "Example: ./update_wiki.py master 1.8_M4.rc2 33558eacc8a2d3dce3396b9ab2fd0773ac5076bc http://autobuilder.yoctoproject.org/pub/releases/yocto-1.8_M4.rc2/ 2015-04-03"
    exit(1)

poky_version = poky_version.replace("yocto-","")
#++++++++++++++++++++
#   Get testruns    +
#++++++++++++++++++++

t = Testopia('ionutx.chisanovici@intel.com', 'thefatlady', 'https://bugzilla.yoctoproject.org/xmlrpc.cgi')

products = {'Fedora':[],
'Ubuntu':[],
'Centos':[],
'Opensuse':[],
'Edgerouter':[],
'GenericX86':[],
'GenericX86_64':[],
'qemux86':[],
'qemuarm':[],
'qemumips':[],
'qemuppc':[],
'qemux86_64':[],
'Eclipse Plugin':[],
'Meta-yocto':[],
'Hob':[],
'Toaster':[],
'OE-Core':[],
'BitBake':[],
'Runtime':[]
}

product_environments = {'GenericX86_64':['genericx86-64 on NUC', 'genericx86-64 on Sugarbay'],
                'GenericX86':['generic-x86 on AtomPC'],
                'qemux86':['qemu-x86'],
                'qemux86_64':['qemux86-64'],
                'qemuarm':['qemuarm'],
                'qemumips':['qemumips'],
                'qemuppc':['qemuppc'],
                'Hob':['Ubuntu 14.04 x86_64','Ubuntu 14.10 x86_64','Ubuntu 15.04 x86_64'],
                'BitBake':['Ubuntu 14.04 x86_64','Ubuntu 14.10 x86_64','Ubuntu 15.04 x86_64'],
                'Runtime':['Multiple Environments'],
                'OE-Core':['Ubuntu 14.04 x86_64','Ubuntu 14.10 x86_64','Ubuntu 15.04 x86_64'],
                'Meta-yocto':['Ubuntu 14.04 x86_64','Ubuntu 14.10 x86_64','Ubuntu 15.04 x86_64'],
                'Kepler':['Ubuntu 14.04 x86_64','Ubuntu 14.10 x86_64','Ubuntu 15.04 x86_64'],
                'Toaster':['Ubuntu 14.04 x86_64','Ubuntu 14.10 x86_64','Ubuntu 15.04 x86_64'],
                "Edgerouter":['EdgeRouter'],
                'Fedora':['Fedora 21 x86_64'],
                'Ubuntu':['Ubuntu 14.04 x86_64','Ubuntu 14.10 x86_64','Ubuntu 15.04 x86_64'],
                'Centos':['CentOS 7 x86_64'],
                'Opensuse':['OpenSuse 13.2 x86_64'],
}

def get_environment(product):
    for environment in product_environments:
        if environment == product:
            return product_environments[environment]    
    return ['Ubuntu 15.04 x86_64']

def get_product_id(product, branch):
    found = 0
    tp = t.testplan_list(name=product+': '+branch+' branch')
    if tp != []:
        product_id = tp[0]['product_id']
        return product_id
    else:
        tp = t.testplan_list(name=product+': '+str(branch).lower()+' branch')
        if tp != []:
            product_id = tp[0]['product_id']
            return product_id
        else:
            if ('edora' in product or 'buntu' in product or 'entos' in product or 'pensuse' in product):
                tp = t.testplan_list(name="Automated Build Testing"+': '+str(branch).lower()+' branch')
            else:
                tp = t.testplan_list(name="BSP/QEMU"+': '+str(branch).lower()+' branch')
            if tp != []:
                product_id = tp[0]['product_id']
                return product_id
            else:            
                print "Cannot find product!"
                exit(1)

def get_plan_id(product, branch):
    tp = t.testplan_list(name=product+': '+branch+' branch')
    if tp != []:
        plan_id = tp[0]['plan_id']    
        return plan_id
    else:
        if ('edora' in product or 'buntu' in product or 'entos' in product or 'pensuse' in product):
            tp = t.testplan_list(name="Automated Build Testing"+': '+branch+' branch')
            plan_id = tp[0]['plan_id']
        else:
            tp = t.testplan_list(name="BSP/QEMU"+': '+branch+' branch')
            plan_id = tp[0]['plan_id']
        return plan_id

def get_env_id(product_id, env):
    tp_envs = t.product_get_environments(product_id)
    env_list = []
    for envs in tp_envs:
        for envz in env:
            if envz == str(envs['name']):
                env_list.append(envs['environment_id'])
    return env_list

def get_build_id(product_id, poky_version, poky_commit, fp_date):
    tp_builds = t.product_get_builds(product_id)
    found = 0
    for build in tp_builds:
        if ((poky_version+": "+poky_commit == str(build['name'])) and (fp_date == str(build['description']))):
            found = 1
            return build['build_id']
    if (found == 0):
        print "Cannot find the build id. Trying to find the closest match..."
        baseline = 0.75
        guess = ""
        for build in tp_builds:
            if SM(None, poky_version+": "+poky_commit, str(build['name'])).ratio() > baseline:
                guess = build['build_id']
                baseline = SM(None, poky_version+": "+poky_commit, str(build['name'])).ratio()
                found = 1
        if (found == 1):
            print "A close match found:"
            print str(guess)
            return guess
        else:
            print "Cannot find a close match!"

def get_run_ids(plan_id, summary, build_id, env_id):
    plan = t.testplan_get_test_runs(plan_id)
    run_ids = []
    if (not build_id and not env_id):
        for run in plan:
            if re.match(r''+summary+'', run['summary']):
                run_ids.append(run['run_id'])
    else:
        for run in plan:
            for envz in env_id:
                if (re.match(r''+summary+'', run['summary']) and (build_id == run['build_id']) and (envz == run['environment_id'])):
                    run_ids.append(run['run_id'])
    return run_ids

'''
product = "EdgeRouter"
summary = '^'+date
print "Plan id:"
print get_plan_id(product,branch)
print "Product id:"
print get_product_id(product, branch)
print "Environment:"
print get_environment(product)
print "Build id:"
print get_build_id(get_product_id(product, branch), poky_version, poky_commit, date)
print "Env id:"
print get_env_id(get_product_id(product, branch),get_environment(product))
print "Run ids:"
print get_run_ids(get_plan_id(product,branch), summary, get_build_id(get_product_id(product, branch), poky_version, poky_commit, date), get_env_id(get_product_id(product, branch),get_environment(product)))
'''

for product in products:
    try:        
        summary = '^'+date
        products[product] = get_run_ids(get_plan_id(product,branch), summary, get_build_id(get_product_id(product, branch), poky_version, poky_commit, date), get_env_id(get_product_id(product, branch),get_environment(product)))
    except:
        print "Cannot get run id for "+str(product)
        pass

print products
