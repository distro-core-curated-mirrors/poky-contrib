#!/usr/bin/python

import os
import sys
import time
import subprocess
import pexpect
import re

try:
    commit = str(sys.argv[1])
    date = str(sys.argv[2])
    repo_link = str(sys.argv[3])
    branch = str(sys.argv[4])
    qt3_commit = str(sys.argv[5])
except IndexError, NameError:
    print "Usage: create_lava_jobs <commit> <date> <link> <branch> <qt3_commit> [weekly | sanity | runwic]\n\
    Example: create_lava_jobs 8b3d3e7c957ad06c390886487f69aeb8e145da6a 2015-03-25 http://autobuilder.yoctoproject.org/pub/releases/yocto-1.8_M4.rc1 master 3016129d90b7ac8517a5227d819f10ad417b5b45"
    exit(1)

try:
    isweekly = str(sys.argv[6])
except:
    isweekly = "no"

# Removed ptest until fixed
lava_jobs = ["genericx86_minnowmax","genericx86-64_minnowmax","genericx86-lsb_minnowmax","genericx86-64_nuc","genericx86-64-lsb_nuc",\
"qemux86","qemux86_64","qemuarm","qemumips","qemuppc","distro", "wic", "toaster"]
weekly_lava_jobs = ["genericx86_minnowmax","genericx86-64_nuc","qemux86","qemux86_64","qemuarm","qemumips","qemuppc","oe-selftest", "wic"]
sanity_lava_jobs = ["genericx86-64_minnowmax", "qemux86", "oe-selftest"]

extra_param1 = ""

if (isweekly != "no"):
    lava_jobs = weekly_lava_jobs
if (isweekly == "sanity"):
    lava_jobs = sanity_lava_jobs
if (isweekly == "runwic"):
    lava_jobs = ["runwic"]

def get_yocto_version():
    version = re.search("[0-9]\.[0-9]", repo_link)
    version = version.group(0)
    if "+snapshot" in repo_link:
        version = str(float(version.replace("+snapshot","")) + 0.1)
    if not version:
        version = "2.0"
    return version


suite = "auto"
timeout = "41600"
buildset = "nightly-qa-distro"

def set_template(template_type, *kwargs):

    if (template_type=="bsp_template"):
        template="""{
            "actions": [
                {
                    "command": "dummy_deploy",
                    "parameters": {
                        "target_type": "ubuntu"
                    }
                },
                {
                    "command": "lava_test_shell",
                    "parameters": {
                        "testdef_repos": [
                            {
                                "parameters": {
                                    "commit": "%s",
                                    "date": "%s",
                                    "repo_link": "%s",
                                    "retest": "no",
                                    "suite": "%s",
                                    "target": "%s",
                                    "test_type": "%s",
                                    "notifications": "yes",
                                    %s
                                    "testrun_type": "%s"
                                },
                                "url": "%s"
                            }
                        ],
                        "timeout": %s
                    }
                },
                {
                    "command": "submit_results",
                    "parameters": {
                        "server": "http://admin@10.237.112.80/RPC2/",
                        "stream": "/private/personal/admin/hardware-testing/"
                    }
                }
            ],
            "job_name": "%s-%s",
            "target": "%s",
            "timeout": %s
        }""" % (commit, date, repo_link, suite, target, test_type, extra_param1, testrun_type, yaml_url, timeout, target, testrun_type, worker, timeout)
    else:
        template = """{
            "actions": [
                {
                    "command": "dummy_deploy",
                    "parameters": {
                        "target_type": "ubuntu"
                    }
                },
                {
                    "command": "lava_test_shell",
                    "parameters": {
                        "testdef_repos": [
                            {
                                "parameters": {
                                    "branch": "%s",
                                    "buildset": "%s",
                                    "fp_date": "%s",
                                    "poky_commit": "%s",
                                    "qt3_commit": "%s"
                                },
                                "url": "%s"
                            }
                        ],
                        "timeout": %s
                    }
                },
                {
                    "command": "submit_results",
                    "parameters": {
                        "server": "http://admin@10.237.112.80/RPC2/",
                        "stream": "/private/personal/admin/distro-testing-job-results/"
                    }
                }
            ],
            "job_name": "Trigger-%s",
            "target": "%s",
            "timeout": %s
        }""" % (branch, buildset, date, commit, qt3_commit, yaml_url, timeout, job, worker, timeout)
    return template

for job in lava_jobs:
    if ("genericx86" in job):
        yaml_url = "file:///var/lib/lava/dispatcher/tmp/testdefs/runtime.yaml"
        target = str(job)
        test_type = "runtime"
        testrun_type = "weekly"
        worker = "lavaworker02"
        json_template = set_template("bsp_template", commit, date, repo_link, suite, target, test_type, testrun_type, yaml_url, timeout, target, testrun_type, worker)
    elif ("qemu" in job):
        yaml_url = "file:///var/lib/lava/dispatcher/tmp/testdefs/runtime.yaml"
        target = str(job)
        test_type = "runtime"
        testrun_type = "weekly"
        worker = "lavaworker03"
        json_template = set_template("bsp_template", commit, date, repo_link, suite, target, test_type, testrun_type, yaml_url, timeout, target, testrun_type, worker)
    elif ("runwic" in job):
        yaml_url = "file:///var/lib/lava/dispatcher/tmp/testdefs/wic.yaml"
        target = str(job)
        test_type = "runtime"
        testrun_type = "weekly"
        worker = "lavaworker02"
        extra_param1 = '"core_type": "core-image-sato",\
        "machine": "nuc",\
        "yocto_version": "'+get_yocto_version()+'",\
        "image_type": "genericx86-64",'
        json_template = set_template("bsp_template", commit, date, repo_link, suite, target, test_type, extra_param1, testrun_type, yaml_url, timeout, target, testrun_type, worker)
    elif (job == "wic"):
        yaml_url = "file:///var/lib/lava/dispatcher/tmp/testdefs/trigger_build.yaml"
        worker = "lavaworker01"
        buildset = "nightly-wic"
        json_template = set_template("distro_template", branch, buildset, date, commit, qt3_commit, yaml_url, timeout, worker, job)        
    elif (job == "oe-selftest"):
        yaml_url = "file:///var/lib/lava/dispatcher/tmp/testdefs/trigger_build.yaml"
        worker = "lavaworker01"
        buildset = "nightly-oe-selftest"
        json_template = set_template("distro_template", branch, buildset, date, commit, qt3_commit, yaml_url, timeout, worker, job)
    elif (job == "toaster"):
        yaml_url = "file:///var/lib/lava/dispatcher/tmp/testdefs/toaster.yaml"
        target = str(job)
        test_type = "runtime"
        testrun_type = "weekly"
        worker = "lavaworker01"
        json_template = set_template("bsp_template", commit, date, repo_link, suite, target, test_type, testrun_type, yaml_url, timeout, target, testrun_type, worker)
    elif (job == "distro"):
        yaml_url = "file:///var/lib/lava/dispatcher/tmp/testdefs/trigger_build.yaml"
        worker = "lavaworker01"
        buildset = "nightly-qa-distro"
        json_template = set_template("distro_template", branch, buildset, date, commit, qt3_commit, yaml_url, timeout, worker, job)
    elif (job == "ptest"):
        yaml_url = "file:///var/lib/lava/dispatcher/tmp/testdefs/runtime.yaml"
        worker = "lavaworker02"
        target = str(job)
        suite = "_ptest"
        repo_link = repo_link+"/ptest/"
        test_type = "runtime"
        testrun_type = "weekly" 
        json_template = set_template("bsp_template", commit, date, repo_link, suite, target, test_type, testrun_type, yaml_url, timeout, target, testrun_type, worker)

    bundlename = job+".json"
    with open(bundlename, 'w') as the_file:
        the_file.write(json_template)
    
    #scp = "scp "+bundlename+" root@10.237.112.80:/lava_jobs/" #for non lava server
    scp = "cp "+bundlename+" /lava_jobs/"
    print scp
    os.system(scp)
        #submit_file = subprocess.check_output("sudo ssh root@10.237.112.80 \"cd /lava_jobs/ && lava-tool submit-job http://admin@localhost/RPC2/ "+bundlename+"\"", shell=True)
        #print submit_file
    password = 'qwe123'
    #command = "ssh root@10.237.112.80 \"lava-tool submit-job http://admin@localhost/RPC2/ /lava_jobs/"+bundlename+"\""  #for non lava server
    command = "lava-tool submit-job http://admin@localhost/RPC2/ /lava_jobs/"+bundlename
    print command
    ssh_new_conn = 'Are you sure you want to continue connecting'
    p = pexpect.spawn(command, timeout=360)
    i = p.expect([ssh_new_conn,'Please enter password for encrypted keyring: ',pexpect.EOF])
    print ' Initial pexpect command output: ', i
    if i == 0:
        # send 'yes'
        p.sendline('yes')
        i = p.expect(['Please enter password for encrypted keyring: ',pexpect.EOF])
        print 'sent yes. pexpect command output', i
        if i == 0:
            # send the password
            p.sendline(password)
            p.expect(pexpect.EOF)
    elif i == 1:
        # send the password
        p.sendline(password)
        p.expect(pexpect.EOF)
    elif i == 2:
        print "pexpect faced key or connection timeout"
        pass
    p.close

print "Cleaning up jsons..."
os.system('rm *.json')