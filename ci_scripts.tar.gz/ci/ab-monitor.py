#!/usr/bin/env python
import os
import sys
import time
import subprocess
import requests
import smtplib
import urllib
import re
from datetime import datetime, timedelta
import signal
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

os_version = "Ubuntu 15.04 x86_64"
run_sanity = True
ab_monitor_version = "1.0.14"
# Fix the version check
sleep_time = 3600

def add_log(message):
    with open("ab-monitor.log", "a") as logfile:
        logfile.write(time.strftime('%Y-%m-%d[%H:%M]: ')+message+"\n")

def sigterm_handler(signal, frame):
    add_log("AB monitor stopped.")
    exit(0)

def get_last_build_ran():
    last_build = 0
    last_name = 0
    if os.path.isfile("ab-monitor.cfg"):
        with open("ab-monitor.cfg", "r") as cfgfile:
            params = cfgfile.readline().split("(")
            try:
                last_build = params[0].strip()
                last_name = params[1].strip()
                last_name = last_name[:-1]
                add_log("Last build ran: \""+str(last_build)+"\"")
                add_log("Last poky number: \""+str(last_name)+"\"")
            except:
                add_log("No previous build recorded. Using none!")
                return (0, 0)
        if not last_build.isdigit():
            add_log("No previous build recorded. Using none.")
            return (0, 0)
        else:
            return (last_build, last_name)
    else:
        add_log("No previous build recorded. Using none.")
        return (0, 0)

def set_last_build_ran(message):
    with open("ab-monitor.cfg", "w") as cfgfile:
        cfgfile.write(message)

def send_mail(msg):
    sender = "george.l.musat@intel.com"
    receiver = "yocto.qa.automated.test.results@intel.com"

    main_mail_body = MIMEMultipart('alternative')
    if (is_release() == "True"):
        main_mail_body['Subject'] = "New release build started!"
    elif (is_weekly() == "True"):
        main_mail_body['Subject'] = "New weekly build started!"
    else:
        main_mail_body['Subject'] = "New sanity build started!"
    main_mail_body['From'] = "george.l.musat@intel.com"
    #main_mail_body['To'] = "yocto.qa.automated.test.results@intel.com"
    main_mail_body['To'] = "yocto-qa-test-results@eclists.intel.com"

    SERVER = "linux.intel.com"


    part1 = MIMEText(msg, 'plain')
    main_mail_body.attach(part1)

    print "Emailing results..."
    try:
        s = smtplib.SMTP(SERVER)
        s.sendmail(sender, receiver, str(main_mail_body))
        s.quit()
        print "Results succesfully sent."
    except smtplib.SMTPException as e:
        print "Error: unable to send email to recipients %s" % e

builds_url = "https://autobuilder.yoctoproject.org/main/json/builders/nightly?as_text=1"

def get_last_build():
    try:
        page = requests.get(builds_url)
        builds = page.text.encode('ascii','ignore')
        content = builds.splitlines()
        last_build = ""
        for i in xrange(len(content)):
            if "]," == content[i].strip():
                last_build = content[i-1].strip()
                break
        return last_build
    except:
        if os.path.isfile("ab-monitor.cfg"):
            with open("ab-monitor.cfg", "r") as cfgfile:
                params = cfgfile.readline().split("(")    
                try:
                    last_build = params[0].strip()
                    return last_build
                except:
                    return None
        else:
            return None

def was_sanity():
    if os.path.isfile("ab-monitor.cfg"):
        with open("ab-monitor.cfg", "r") as cfgfile:
            params = cfgfile.readline().split("(")
            try:
                last_build = params[1].strip()
                if "sanity" in last_build:
                    return True
                else:
                    return False
            except:
                return False
    else:
        return False

def get_from_ab(value, buildnum=None):
    try:
        if not buildnum:
            status_url = "https://autobuilder.yoctoproject.org/main/json/builders/nightly/builds/"+get_last_build()+"?as_text=1"
        else:
            status_url = "https://autobuilder.yoctoproject.org/main/json/builders/nightly/builds/"+buildnum+"?as_text=1"
        #add_log("[DEBUG] Looking in : "+status_url)
        page = requests.get(status_url)
        builds = page.text.encode('ascii','ignore')
        content = builds.splitlines()
        release_string = ""
        for i in xrange(len(content)):
            if value in content[i]:
                release_string = content[i+1].strip()[:-1].replace('"','')
        return release_string
    except:
        add_log("Cannot contact Autobuilder")
        return None

def is_weekly():
    try:
        return get_from_ab("custom_send_email")
    except:
        return "False"

def is_release():
    try:
        return get_from_ab("custom_release_me")
    except:
        return "False"

def is_url(url):
    status = urllib.urlopen(url).getcode()
    if (status == 200):
        return True
    else:
        return False

def get_last_build_date():
    date = datetime.now() - timedelta(hours=72)
    found = False
    if os.path.isfile("ab-monitor.log"):
        with open("ab-monitor.log", "r") as cfgfile:
            for line in cfgfile:
                #log_line = re.search("(.*\[.*\]: New (weekly|release) build found)", line)
                log_line = re.search("(.*\[.*\]: ./create_lava_jobs.py)", line)
                if log_line:
                    date = str(log_line.group()).split(": ")[0].split("[")[0]
                    found = True
        if found:
            return datetime(int(date.split("-")[0]),int(date.split("-")[1]),int(date.split("-")[2]))
        else:
            return datetime.now() - timedelta(hours=72) # set last build date 3 days ago to let it run if there is no log file 
    else:
        return datetime.now() - timedelta(hours=72)

def get_last_sanity_build():
    date = datetime.now() - timedelta(hours=72)
    found = False
    if os.path.isfile("ab-monitor.log"):
        with open("ab-monitor.log", "r") as cfgfile:
            for line in cfgfile:
                log_line = re.search("(.*\[.*\]: New sanity build found)", line)
                if log_line:
                    date = str(log_line.group()).split(": ")[0].split("[")[0]
                    found = True
        if found:
            return datetime(int(date.split("-")[0]),int(date.split("-")[1]),int(date.split("-")[2]))
        else:
            return datetime.now() - timedelta(hours=72) # set last build date 3 days ago to let it run if there is no log file 
    else:
        return datetime.now() - timedelta(hours=72)

def is_ab_busy():
    nr_proc = subprocess.check_output("sudo ssh root@10.237.112.85 \"ps -ef | grep bitbake | grep -v grep | grep -v decafbad | wc -l\"", shell=True)
    if str(nr_proc).strip() != "0":
        return True
    else:
        return False


def days_from_last_build():
    present = datetime.now()
    last_build_days = str(present - get_last_build_date()).split(",")[0].replace(" days","")
    last_build_days = last_build_days.replace(" day","")
    try:
        last_build_days = int(last_build_days)
    except:
        last_build_days = "0"
    if last_build_days:
        return int(last_build_days)
    else:
        return 3

def days_from_last_sanity_build():
    present = datetime.now()
    last_build_days = str(present - get_last_sanity_build()).split(",")[0].replace(" days","")
    last_build_days = last_build_days.replace(" day","")
    try:
        last_build_days = int(last_build_days)
    except:
        last_build_days = "0"
    if last_build_days:
        return int(last_build_days)
    else:
        return 3

def wait_for_links_available(buildnum, yocto_number):
    try:
        dest = get_from_ab("DEST", buildnum).replace('/srv/www/vhosts/','') #autobuilder.yoctoproject.org/pub/releases/yocto-1.8_M4.rc1
        ab_url = "http://"+dest
    except:
        ab_url = None
    if (is_url(ab_url) == False or ab_url[-1:] == "-"):
        add_log("Bad autobuilder url. Trying somethin else...")
        ab_url += yocto_number
        if (is_url(ab_url) == False):
            add_log("Autobuilder url does not work. ("+ab_url+")")
            ab_url = None
    add_log("Presumed autobuilder url is %s" % ab_url)
    if ab_url != None:
        genericx86_image = ab_url+"/machines/genericx86/core-image-sato-sdk-genericx86.hddimg"
        genericx86_64_image = ab_url+"/machines/genericx86-64/core-image-sato-sdk-genericx86-64.hddimg"
        ptest_image = ab_url+"/ptest/machines/genericx86-64/core-image-sato-sdk-genericx86-64.hddimg"
        lsb_image = ab_url+"/machines/genericx86-64-lsb/core-image-lsb-sdk-genericx86-64.hddimg"
        tries = 0
        while tries < 9:
            if not is_url(genericx86_image) or not is_url(genericx86_64_image) or not is_url(ptest_image) or not is_url(lsb_image):
                add_log("Test images are not available on the autobuilder. Waiting an hour.")
                time.sleep(3600)
                tries += 1
            else:
                add_log("All images are available for download.")
                return ab_url
    else:
        add_log("Forced testrun failed because autobuilder url is broken!")
        return None

def start_testing(yocto_number, poky_name, branch, is_sanity=False, delay=0, buildnum=None):
    add_log("Waiting %s seconds before starting." % delay)
    time.sleep(delay)
    commit = get_from_ab("got_revision", buildnum) #8b3d3e7c957ad06c390886487f69aeb8e145da6a
    qt3 = get_from_ab("got_revision_meta-qt3", buildnum) #3016129d90b7ac8517a5227d819f10ad417b5b45
    add_log("Checking that images are built on the autobuilder...")
    ab_url = wait_for_links_available(buildnum, yocto_number)

    if (not poky_name or not yocto_number or not commit or not qt3 or not ab_url):
        add_log("Cannot detect all variables! Skipping.")
        if not poky_name:
            add_log("poky_name is empty!")
        if not yocto_number:
            add_log("yocto_number is empty!")
        if not commit:
            add_log("commit is empty!")
        if not qt3:
            add_log("qt3 is empty!")
        if not ab_url:
            add_log("ab_url is empty!")
        set_last_build_ran(get_last_build()+"("+yocto_number+")")
    else:                
        add_log("Poky name: "+poky_name)
        add_log("Yocto number: "+yocto_number)
        add_log("Commit: "+commit)
        add_log("Meta QT3: "+qt3)
        add_log("Autobuilder url: "+ab_url)
        add_log("Creating test runs in testopia...")

        if is_sanity:
            add_log("New sanity build found: "+get_last_build())
            command = "./create_lava_jobs.py "+commit+" "+time.strftime('%Y-%m-%d')+" "+ab_url+" "+poky_name+" "+qt3+" sanity"
            add_log(command)
            status = os.system(command)        
            if (status != 0):
                add_log("Could not start LAVA jobs!")
                send_mail("Something went wrong and could not create LAVA jobs!")
            yocto_number = "sanity"          
        else:
            if (is_release() == "True"):
                # Create all test runs
                command = "./update_testopia.py create all all "+poky_name+" "+yocto_number+" "+commit+" "+time.strftime('%Y-%m-%d')+" \""+os_version+"\""
                add_log(command)
                status = os.system(command)
                # Create wiki page
                command = "python update_wiki.py "+branch+" "+yocto_number+" "+commit+" "+ab_url+" "+time.strftime('%Y-%m-%d')+" \'"+os_version+"\'"
                add_log(command)
                status = os.system(command)
            else:
                command = "./update_testopia.py create all weekly "+poky_name+" "+yocto_number+" "+commit+" "+time.strftime('%Y-%m-%d')+" \""+os_version+"\""
                add_log(command)
                status = os.system(command)
            if (status != 0):
                add_log("Could not create testopia test-runs!")
            if (is_release() == "True"):
                command = "./create_lava_jobs.py "+commit+" "+time.strftime('%Y-%m-%d')+" "+ab_url+" "+poky_name+" "+qt3
                add_log(command)
                status = os.system(command)
            else:
                command = "./create_lava_jobs.py "+commit+" "+time.strftime('%Y-%m-%d')+" "+ab_url+" "+poky_name+" "+qt3+" weekly"
                add_log(command)
                status = os.system(command)
            if (status != 0):
                add_log("Could not start LAVA jobs!")
                send_mail("Something went wrong and could not create LAVA jobs!")
        if not buildnum:
            buildnum = get_last_build()
        add_log("Adding build "+buildnum+" as an already ran build.")
        set_last_build_ran(buildnum+"("+yocto_number+")")
        send_mail("Started build: "+yocto_number+"\n\nCommit: "+commit+"\nBranch: "+branch+"\nAutobuilder url: "+ab_url+"\n\nDate:"+str(time.strftime('%Y-%m-%d')))


add_log("AB Monitor started (version %s)" % ab_monitor_version)

def get_branch(yocto_number):
    branch = "master"
    if yocto_number != "":
        if "1.5" in yocto_number:
            branch = "dora"
        if "1.6" in yocto_number:
            branch = "daisy"
        if "1.7" in yocto_number:
            branch = "dizzy"
        if "1.8" in yocto_number:
            branch = "fido"
        if "1.9" in yocto_number:
            branch = "master"
        if "2.0" in yocto_number:
            branch = "master"            
    return branch

def strip_branch(poky_name):
    branch = "master"
    if poky_name != "":
        if "dora" in poky_name:
            branch = "dora"
        if "daisy" in poky_name:
            branch = "daisy"
        if "dizzy" in poky_name:
            branch = "dizzy"
        if "fido" in poky_name:
            branch = "fido"
        if "master" in poky_name:
            branch = "master"
        if "master-next" in poky_name:
            branch = "master-next"            
    return branch

def check_force_file():
    if os.path.isfile("ab-monitor.build"):
        with open("ab-monitor.build", "r") as cfgfile:
            buildnum = cfgfile.readline().strip()
            if buildnum != "":
                os.remove("ab-monitor.build")
                return buildnum            
    else:
        return None

def sighup_handler(signal, frame):
    add_log("Starting forced run...")
    build = check_force_file()
    if build == None:
        add_log("No information found in ab-monitor.build. Getting from AB...")
        poky_name = get_from_ab("custom_poky_name") #fido
        if poky_name == "":
            poky_name = get_from_ab("branch_poky") #fido
        poky_name = strip_branch(poky_name)
        yocto_number = get_from_ab("custom_yocto_number") #1.8_M4.rc1
        if yocto_number == "":
            yocto_number = get_from_ab("distroversion") #1.8_M4.rc1
        if ("+snapshot") in yocto_number:
            yocto_number = str(float(yocto_number.replace("+snapshot",""))+0.1)
        if (yocto_number == ""):
            yocto_number = "1.9"
    else:
        add_log("Forced running tests on build %s..." % build)
        yocto_number = get_from_ab("custom_yocto_number", build) #1.8_M4.rc1
        if yocto_number == "":
            yocto_number = get_from_ab("distroversion", build) #1.8_M4.rc1
        if (("+snapshot") in yocto_number) or ("+snapshot" in  get_from_ab("distroversion", build)):
            add_log("Increasing distro version because of +snapshot.")
            yocto_number = str(float(yocto_number.replace("+snapshot",""))+0.1)
        if (yocto_number == ""):
            yocto_number = "1.9"
        poky_name = get_branch(yocto_number)            
        #add_log("Yocto number= %s" % yocto_number)
    start_testing(yocto_number, poky_name, get_branch(yocto_number), delay=0, buildnum=build)

while True:
    signal.signal(signal.SIGTERM, sigterm_handler)
    signal.signal(signal.SIGHUP, sighup_handler)
    if (is_weekly() == "True" or is_release() == "True"):
        # Wait an hour and check again to see if there was no mistake
        add_log("New weekly or release build detected. Waiting an hour to be sure...")
        time.sleep(3600)
        #time.sleep(10)
        if (is_weekly() == "True" or is_release() == "True"):
            (last_build_ran, last_number_ran) = get_last_build_ran()
            if (get_last_build() != last_build_ran):
                dflb = days_from_last_build()
                if (is_release() == "True"):
                    add_log("New release build found: "+get_last_build())
                else:
                    add_log("New weekly build found: "+get_last_build())
                poky_name = get_from_ab("custom_poky_name") #fido
                if poky_name == "":
                    poky_name = get_from_ab("branch_poky") #fido
                poky_name = strip_branch(poky_name)
                yocto_number = get_from_ab("custom_yocto_number") #1.8_M4.rc1
                if yocto_number == "":
                    yocto_number = get_from_ab("distroversion", build)
                if (("+snapshot") in yocto_number) or ("+snapshot" in  get_from_ab("distroversion")):
                    add_log("Increasing distro version because of +snapshot.")
                    yocto_number = str(float(yocto_number.replace("+snapshot",""))+0.1)
                if (yocto_number == ""):
                    yocto_number = "2.0"
                yocto_version = re.search("([0-9]\.[0-9])", yocto_number)
                if (last_number_ran != "" and last_number_ran != yocto_number) or (is_release() != "True"):
                    if (float(yocto_version.group()) * 10) > 16:
                        add_log("Yocto version: "+yocto_version.group()+". Version is newer than 1.6, automatic hardware testing is supported.")
                        add_log("Days from last build: "+str(dflb))
                        if (dflb > 1) or was_sanity():
                            start_testing(yocto_number, poky_name, get_branch(yocto_number))
                        else:
                            add_log("Less than 2 days detected before last build. Could be a respin! Sending email.")
                            send_mail("AB Monitor detected a new release less than 2 days before the last one.\n\n Could be a respin!")
                            set_last_build_ran(get_last_build()+"("+yocto_number+")")
                    else:
                        add_log("Yocto version: "+yocto_version.group()+". Versions older that 1.7 does not support automatic hardware testing. Skipping...")
                else:
                    add_log("The build "+yocto_number+" was aleady run. Skipping next %s seconds..." % sleep_time)
            else:
                add_log("The build "+get_last_build()+" was aleady run. Skipping next %s seconds..." % sleep_time)
        else:
            add_log("No weekly or release found now. Probably a mistake. Skipping next %s seconds..." % sleep_time)
    else:
        add_log("No new release found yet. Will look again in "+str(sleep_time)+" seconds. Current build: "+str(get_last_build()))
        if (days_from_last_sanity_build() > 1) and (days_from_last_build() > 1) and ( int(time.strftime('%H')) >= 20) and (not is_ab_busy()) and (run_sanity == True):
            add_log("More than 2 days have passed since last test. Should start a nightly sanity to avoid lazyness.")
            start_testing("1.9","master","master", is_sanity=True)

    time.sleep(sleep_time) # wait between checks