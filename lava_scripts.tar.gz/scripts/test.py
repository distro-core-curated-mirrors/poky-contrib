#!/usr/bin/python

from simplemediawiki import MediaWiki
import os, sys, re
import datetime
from difflib import SequenceMatcher as SM

wiki = MediaWiki('https://wiki.yoctoproject.org/wiki/api.php')

loginData = wiki.call({'action':'login', 'lgname':'Lucian Musat','lgpassword':'wiki1999'}) # For real wiki

#personalLoginData = wiki.call({'action':'login', 'lgname':'MichaelHalstead','lgpassword':'wiki1999','lgtoken': loginData['login']['token']})
personalLoginData = wiki.call({'action':'login', 'lgname':'Lucian Musat','lgpassword':'wiki1999','lgtoken': loginData['login']['token']})

returnData = wiki.call({'action':'query','prop':'info', 'titles':"QA run history",'intoken':'edit'})

print returnData
