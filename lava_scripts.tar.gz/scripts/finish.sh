#!/bin/bash

#ARGs[0] - commit

ARGS=("$@")
if [ "$#" -lt 1 ]; then
    echo "Error: Plase provide all required parameters."
    exit 1
fi

su lava -c 'rsh root@10.237.112.80 "/var/lib/lava/dispatcher/tmp/bundle_streams/bundle_aggregator.py '${ARGS[0]}'"'

