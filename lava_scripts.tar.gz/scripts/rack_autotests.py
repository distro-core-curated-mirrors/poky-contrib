import os
import sys
import unittest
import logging
import time
import datetime
from time import gmtime, strftime

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'meta/lib')))

import oeqa.selftest
import oeqa.utils.ftools as ftools
from oeqa.utils.commands import Command, runCmd, get_bb_var, get_test_layer, bitbake
from oeqa.selftest.base import oeSelfTest


if (len(sys.argv)<7):
    print "Not enaugh arguments passed!"
    exit(1)

autoconf_file = os.path.join(os.environ['BUILDDIR'], 'conf', 'auto.conf')
required_packages = "rpm psplash"
test_image_types = ['core-image-sato-sdk']
repo_link = str(sys.argv[1]) #"http://autobuilder.yoctoproject.org/pub/releases/yocto-1.7.rc1" "yaml - repo_link"
bundle_context = repo_link.split("/")[-1]

#bundle contex fix
if "+snapshot" in bundle_context:
    bundle_context = str(float(bundle_context.replace("+snapshot","")) + 0.1)

if (bundle_context == ""):
    bundle_context = repo_link.split("/")[-2]
    #yocto-meta-intel-3.1-fido-1.8?
    if "1.7" in bundle_context:
        bundle_context = "1.7"
    elif "1.8" in bundle_context:
        bundle_context = "1.8"
    elif "1.9" in bundle_context:
        bundle_context = "1.9"

bundle_test_type = str(sys.argv[2]) #"runtime" "yaml - test_type"
bundle_testrun_type = str(sys.argv[3]) #"weekly" "yaml - testrun_type"
bundle_commit = str(sys.argv[4]) #"8ac8eca2e3bd8c78e2b31ea974930ed0243258a3" "yaml - commit"
bundle_date = str(sys.argv[5]) #"2014-09-24" "yaml - date"
machine_name = str(sys.argv[6]) #yaml - target
test_suite = str(sys.argv[7]) #yaml - suite
try:
    notifications = str(sys.argv[8]) #yaml - suite
except:
    notifications = "yes"

machine_name = machine_name.replace("cherrytrail","cherryhill")

if test_suite == "":
    test_suite = "auto"

def get_branch():
    branch = "master"
    if bundle_context != "unknown":
        if "1.5" in bundle_context:
            branch = "dora"
        if "1.6" in bundle_context:
            branch = "daisy"
        if "1.7" in bundle_context:
            branch = "dizzy"
        if "1.8" in bundle_context:
            branch = "fido"
        if "1.9" in bundle_context:
            branch = "master"            
    return branch

def print_lava(string):
  os.system('echo '+string)

os_version = "Ubuntu 14.10 x86_64"

pw_control3 = '"'+str(os.path.join(os.environ['BUILDDIR'],'powercontrol3.exp'))+'"'
test_serial_control = '"'+str(os.path.join(os.environ['BUILDDIR'],'test-serialcontrol.exp'))


qemux86_conf = {
'qemux86':
"""
MACHINE = "qemux86"
INHERIT += "testimage"
TEST_SUITES = " """+str(test_suite)+""" "

""",
}

qemux86_64_conf = {
'qemux86-64':
"""
MACHINE = "qemux86-64"
INHERIT += "testimage"
TEST_SUITES = " """+str(test_suite)+""" "

""",
}

qemuarm_conf = {
'qemuarm':
"""
MACHINE = "qemuarm"
INHERIT += "testimage"
TEST_SUITES = " """+str(test_suite)+""" "

""",
}

qemumips_conf = {
'qemumips':
"""
MACHINE = "qemumips"
INHERIT += "testimage"
TEST_SUITES = " """+str(test_suite)+""" "

""",
}

qemuppc_conf = {
'qemuppc':
"""
MACHINE = "qemuppc"
INHERIT += "testimage"
TEST_SUITES = " """+str(test_suite)+""" "
""",
}


genericx86_nuc_conf = {
'genericx86_nuc':
"""
BB_NUMBER_THREADS ?= "16"
PARALLEL_MAKE ?= "-j 16"
MACHINE = "genericx86"
IMAGE_FSTYPES_append = " tar.gz"
INHERIT += "testimage"
TEST_TARGET = "simpleremote"
TEST_TARGET_IP = "192.168.99.52"
TEST_SUITES = " """+str(test_suite)+""" "
""",
}

genericx86_minnowmax_conf = {
'genericx86_minnowmax':
"""
BB_NUMBER_THREADS ?= "16"
PARALLEL_MAKE ?= "-j 16"
MACHINE = "genericx86"
IMAGE_FSTYPES_append = " tar.gz"
INHERIT += "testimage"
TEST_TARGET = "simpleremote"
TEST_TARGET_IP = "192.168.99.55"
TEST_SUITES = " """+str(test_suite)+""" "
""",
}

genericx86_64_sugarbay_conf = {
'genericx86-64_sugarbay':
"""
BB_NUMBER_THREADS ?= "16"
PARALLEL_MAKE ?= "-j 16"
MACHINE = "genericx86-64"
INHERIT += "testimage"
TEST_TARGET = "simpleremote"
TEST_TARGET_IP = "10.237.112.97:2203"
TEST_POWERCONTROL_CMD = """+str(pw_control3)+"""
TEST_POWERCONTROL_EXTRA_ARGS = "test 10.237.112.97 sugarbay1 120"
IMAGE_FSTYPES_append = " tar.gz"
TEST_SERIALCONTROL_CMD = """+str(test_serial_control)+""" sugarbay1"
INHERIT += "buildhistory"

TEST_SUITES = " """+str(test_suite)+""" "
""",
}

genericx86_64_nuc_conf = {
'genericx86-64_nuc':
"""
BB_NUMBER_THREADS ?= "16"
PARALLEL_MAKE ?= "-j 16"
MACHINE = "genericx86-64"
INHERIT += "testimage"
TEST_TARGET = "simpleremote"
TEST_TARGET_IP = "192.168.99.52"
IMAGE_FSTYPES_append = " tar.gz"
TEST_SUITES = " """+str(test_suite)+""" "
""",
}

genericx86_64_minnowmax_conf = {
'genericx86-64_minnowmax':
"""
BB_NUMBER_THREADS ?= "16"
PARALLEL_MAKE ?= "-j 16"
MACHINE = "genericx86-64"
INHERIT += "testimage"
TEST_TARGET = "simpleremote"
TEST_TARGET_IP = "192.168.99.56"
IMAGE_FSTYPES_append = " tar.gz"
TEST_SUITES = " """+str(test_suite)+""" "
""",
}

ptest_conf = {
'ptest':
"""
BB_NUMBER_THREADS ?= "16"
PARALLEL_MAKE ?= "-j 16"
MACHINE = "genericx86-64"
INHERIT += "testimage"
TEST_TARGET = "simpleremote"
TEST_TARGET_IP = "192.168.99.52"
IMAGE_FSTYPES_append = " tar.gz"
INHERIT += "buildhistory"
IMAGE_FEATURES_append = " ptest-pkgs"
IMAGE_INSTALL_append = " ptest-runner"
TEST_SUITES = "_ptest"
""",
}

############## meta-intel ####################

#minnowmax32
core2_32_conf = {
'intel-core2-32':
"""
BB_NUMBER_THREADS ?= "16"
PARALLEL_MAKE ?= "-j 16"
MACHINE = "intel-core2-32"
INHERIT += "testimage"
TEST_TARGET_IP = "192.168.99.55"
TEST_TARGET = "simpleremote"
TEST_SUITES = " """+str(test_suite)+""" "
""",
}

corei7_64_nuc_conf = {
'intel-corei7-64_nuc':
"""
BB_NUMBER_THREADS ?= "16"
PARALLEL_MAKE ?= "-j 16"
MACHINE = "intel-corei7-64"
INHERIT += "testimage"
TEST_TARGET_IP = "192.168.99.52"
TEST_TARGET = "simpleremote"
TEST_SUITES = " """+str(test_suite)+""" "
""",
}

corei7_64_cherryhill_conf = {
'intel-corei7-64_cherryhill':
"""
BB_NUMBER_THREADS ?= "16"
PARALLEL_MAKE ?= "-j 16"
MACHINE = "intel-corei7-64"
INHERIT += "testimage"
TEST_TARGET_IP = "192.168.99.57"
TEST_TARGET = "simpleremote"
TEST_SUITES = " """+str(test_suite)+""" "
""",
}

corei7_64_minnowmax_conf = {
'intel-corei7-64_minnowmax':
"""
BB_NUMBER_THREADS ?= "16"
PARALLEL_MAKE ?= "-j 16"
MACHINE = "intel-corei7-64"
INHERIT += "testimage"
TEST_TARGET_IP = "192.168.99.56"
TEST_TARGET = "simpleremote"
TEST_SUITES = " """+str(test_suite)+""" "
""",
}


nuc_conf = {
'nuc':
"""
MACHINE = "nuc"
INHERIT += "testimage"
TEST_TARGET = "GummibootTarget"
BB_NUMBER_THREADS ?= "16"
PARALLEL_MAKE ?= "-j 16"
TEST_TARGET_IP = "192.168.99.52"
TEST_POWERCONTROL_CMD = """+str(pw_control3)+"""
TEST_POWERCONTROL_EXTRA_ARGS = "test 10.237.112.97 nuc1 120"
IMAGE_FSTYPES_append = " tar.gz"

TEST_SUITES = " """+str(test_suite)+""" "
""",
}

sugarbay_conf = {
'sugarbay':
"""
BB_NUMBER_THREADS ?= "16"
PARALLEL_MAKE ?= "-j 16"
MACHINE = "sugarbay"
INHERIT += "testimage"
TEST_TARGET = "GrubTarget"
TEST_TARGET_IP = "10.237.112.97:2203"
TEST_POWERCONTROL_CMD = """+str(pw_control3)+"""
TEST_POWERCONTROL_EXTRA_ARGS = "test 10.237.112.97 sugarbay1 120"
IMAGE_FSTYPES_append = " tar.gz"
TEST_SERIALCONTROL_CMD = """+str(test_serial_control)+""" sugarbay1"
INHERIT += "buildhistory"

TEST_SUITES = " """+str(test_suite)+""" "
""",
}

configurations = genericx86_nuc_conf

print_lava("Machine name: %s " % machine_name)

log_path = "results.log"

if (machine_name == "genericx86_nuc"):
    print_lava("Running only the genericx86 on NUC...")
    configurations = genericx86_nuc_conf
    log_path = "tmp/work/genericx86-poky-linux/core-image-sato-sdk/1.0-r0/core-image-sato-sdk-1.0/results-bitbake-worker.log"

if (machine_name == "genericx86_minnowmax"):
    print_lava("Running only the genericx86 on Minnowboard Max...")
    configurations = genericx86_minnowmax_conf
    log_path = "tmp/work/genericx86-poky-linux/core-image-sato-sdk/1.0-r0/core-image-sato-sdk-1.0/results-bitbake-worker.log"

if (machine_name == "genericx86-lsb_minnowmax"):
    print_lava("Running only the genericx86 LSB on Minnowboard Max...")
    genericx86_minnowmax_conf['genericx86_minnowmax'] += "DISTRO = \"poky-lsb\""
    configurations = genericx86_minnowmax_conf
    log_path = "tmp/work/genericx86-poky-linux/core-image-lsb-sdk/1.0-r0/core-image-lsb-sdk-1.0/results-bitbake-worker.log"

if (machine_name == "genericx86-64_sugarbay"):
    print_lava("Running only the generic x86_64 on sugarbay...")
    configurations = genericx86_64_sugarbay_conf
    log_path = "tmp/work/genericx86_64-poky-linux/core-image-sato-sdk/1.0-r0/core-image-sato-sdk-1.0/results-bitbake-worker.log"

if (machine_name == "genericx86-64_nuc"):
    print_lava("Running only the generic x86_64 on NUC...")
    configurations = genericx86_64_nuc_conf
    log_path = "tmp/work/genericx86_64-poky-linux/core-image-sato-sdk/1.0-r0/core-image-sato-sdk-1.0/results-bitbake-worker.log"

if (machine_name == "genericx86-64-lsb_nuc"):
    genericx86_64_nuc_conf['genericx86-64_nuc'] += "DISTRO = \"poky-lsb\""
    configurations = genericx86_64_nuc_conf
    print_lava("Running only the generic x86_64 LSB on NUC...")
    log_path = "tmp/work/genericx86_64-poky-linux/core-image-lsb-sdk/1.0-r0/core-image-lsb-sdk-1.0/results-bitbake-worker.log"

if (machine_name == "genericx86-64-lsb_minnowmax"):
    print_lava("Running only the genericx86-64 LSB on Minnowboard Max...")
    genericx86_64_minnowmax_conf['genericx86-64_minnowmax'] += "DISTRO = \"poky-lsb\""
    configurations = genericx86_64_minnowmax_conf
    log_path = "tmp/work/genericx86-poky-linux/core-image-lsb-sdk/1.0-r0/core-image-lsb-sdk-1.0/results-bitbake-worker.log"

if (machine_name == "genericx86-64_minnowmax"):
    print_lava("Running only the generic x86_64 on Minnowboard Max...")
    configurations = genericx86_64_minnowmax_conf
    log_path = "tmp/work/genericx86_64-poky-linux/core-image-sato-sdk/1.0-r0/core-image-sato-sdk-1.0/results-bitbake-worker.log"

if (machine_name == "ptest"):
    print_lava("Running only the ptest on NUC...")
    configurations = ptest_conf
    log_path = "tmp/work/genericx86_64-poky-linux/core-image-sato-sdk/1.0-r0/core-image-sato-sdk-1.0/results-bitbake-worker.log"

if (machine_name == "qemux86"):
    print_lava("Running only the qemux86...")
    configurations = qemux86_conf
    log_path = "tmp/work/qemux86-poky-linux/core-image-sato-sdk/1.0-r0/core-image-sato-sdk-1.0/results-bitbake-worker.log"

if (machine_name == "qemux86_64"):
    print_lava("Running only the qemux86-64...")
    configurations = qemux86_64_conf
    log_path = "tmp/work/qemux86_64-poky-linux/core-image-sato-sdk/1.0-r0/core-image-sato-sdk-1.0/results-bitbake-worker.log"

if (machine_name == "qemuarm"):
    print_lava("Running only the qemuarm...")
    configurations = qemuarm_conf
    log_path = "tmp/work/qemuarm-poky-linux-gnueabi/core-image-sato-sdk/1.0-r0/core-image-sato-sdk-1.0/results-bitbake-worker.log"

if (machine_name == "qemumips"):
    print_lava("Running only the qemumips...")
    configurations = qemumips_conf
    log_path = "tmp/work/qemumips-poky-linux/core-image-sato-sdk/1.0-r0/core-image-sato-sdk-1.0/results-bitbake-worker.log"

if (machine_name == "qemuppc"):
    print_lava("Running only the qemuppc...")
    configurations = qemuppc_conf
    log_path = "tmp/work/qemuppc-poky-linux/core-image-sato-sdk/1.0-r0/core-image-sato-sdk-1.0/results-bitbake-worker.log"

############## meta intel conf ###############

if (machine_name == "sugarbay_sugarbay"):
    print_lava("Running only the meta-intel sugarbay...")
    configurations = sugarbay_conf
    log_path = "tmp/work/sugarbay-poky-linux/core-image-sato-sdk/1.0-r0/core-image-sato-sdk-1.0/results-bitbake-worker.log"

if (machine_name == "nuc_nuc"):
    print_lava("Running only the meta-intel nuc...")
    configurations = nuc_conf
    log_path = "tmp/work/nuc-poky-linux/core-image-sato-sdk/1.0-r0/core-image-sato-sdk-1.0/results-bitbake-worker.log"

if (machine_name == "intel-core2-32_minnowmax"):
    print_lava("Running only the meta-intel core2 32...")
    configurations = core2_32_conf
    log_path = "tmp/work/intel_core2_32-poky-linux/core-image-sato-sdk/1.0-r0/core-image-sato-sdk-1.0/results-bitbake-worker.log"

if (machine_name == "intel-core2-32-lsb_minnowmax"):
    print_lava("Running only the meta-intel core2 32 LSB...")
    configurations = core2_32_conf
    configurations['intel-core2-32'] += "DISTRO = \"poky-lsb\""
    log_path = "tmp/work/intel_core2_32-poky-linux/core-image-lsb-sdk/1.0-r0/core-image-lsb-sdk-1.0/results-bitbake-worker.log"    

if (machine_name == "intel-corei7_64_nuc") or (machine_name == "intel-corei7-64_nuc"):
    print_lava("Running only the meta-intel corei7 64 on NUC...")
    configurations = corei7_64_nuc_conf
    log_path = "tmp/work/intel_corei7_64-poky-linux/core-image-sato-sdk/1.0-r0/core-image-sato-sdk-1.0/results-bitbake-worker.log"   

if (machine_name == "intel-corei7-64_minnowmax"):
    print_lava("Running only the meta-intel corei7 64 on Minnowboard Max...")
    configurations = corei7_64_minnowmax_conf
    log_path = "tmp/work/intel_corei7_64-poky-linux/core-image-sato-sdk/1.0-r0/core-image-sato-sdk-1.0/results-bitbake-worker.log"

if (machine_name == "intel-corei7-64_cherryhill"):
    print_lava("Running only the meta-intel corei7 64 on Cherryhill...")
    configurations = corei7_64_cherryhill_conf
    log_path = "tmp/work/intel_corei7_64-poky-linux/core-image-sato-sdk/1.0-r0/core-image-sato-sdk-1.0/results-bitbake-worker.log"

if (machine_name == "intel-corei7-64-lsb_cherryhill"):
    print_lava("Running only the meta-intel corei7 64 LSB on Cherryhill...")
    corei7_64_cherryhill_conf['intel-corei7-64_cherryhill'] += "DISTRO = \"poky-lsb\""
    configurations = corei7_64_cherryhill_conf
    log_path = "tmp/work/intel_corei7_64-poky-linux/core-image-lsb-sdk/1.0-r0/core-image-lsb-sdk-1.0/results-bitbake-worker.log"

if (machine_name == "intel-corei7-64-lsb_nuc"):
    print_lava("Running only the meta-intel corei7 64 LSB on NUC...")    
    corei7_64_nuc_conf['intel-corei7-64_nuc'] += "DISTRO = \"poky-lsb\""
    configurations = corei7_64_nuc_conf
    log_path = "tmp/work/intel_corei7_64-poky-linux/core-image-lsb-sdk/1.0-r0/core-image-lsb-sdk-1.0/results-bitbake-worker.log"    

if (machine_name == "intel-corei7-64-lsb_minnowmax"):
    print_lava("Running only the meta-intel corei7 64 LSB on Minnowboard...")    
    corei7_64_minnowmax_conf['intel-corei7-64_minnowmax'] += "DISTRO = \"poky-lsb\""
    configurations = corei7_64_minnowmax_conf
    log_path = "tmp/work/intel_corei7_64-poky-linux/core-image-lsb-sdk/1.0-r0/core-image-lsb-sdk-1.0/results-bitbake-worker.log"    


print_lava("Running smoke test on configurations..")
for configuration in configurations:
    result = bitbake('-p', postconfig=configurations[configuration], ignore_status=True)
    print_lava("Status: " + str(result.status))

if ("qemu" in machine_name):
    result = os.system("ps ax | grep Xtightvnc | grep -v grep")
    if (result != 0):
        print_lava("VNC server not started. Trying to start...")
        res = os.system("vncserver")
        if (res != 0):
            print_lava("Warning: May not have started vnc server!")

print_lava("Building packages for each configuration:")
for configuration in configurations:
    if ("qemu" in machine_name):
        required_packages = "core-image-sato-sdk" 
    print_lava("Configuration: " + configuration)
    os.system("echo \'"+configurations[configuration]+"\' >> conf/local.conf")
    string = "Bitbaking required packages " + required_packages
    print_lava(string)
    result = bitbake(required_packages, postconfig=configurations[configuration], ignore_status=True)
    if result != 0:
        print_lava("Warning: bitbake may not have worked properly!")
    print_lava("Bitbaking package index...")
    result = bitbake("package-index", postconfig=configurations[configuration], ignore_status=True)
    if result != 0:
        print_lava("Warning: bitbake may not have worked properly!")
    print_lava("Downloading manifest from AB...")
    manifest_img_type = configuration.replace('_nuc','')
    manifest_img_type = manifest_img_type.replace('_sugarbay','')
    manifest_img_type = manifest_img_type.replace('_minnowmax','')
    manifest_img_type = manifest_img_type.replace('_cherryhill','')
    if ("qemu" not in machine_name):
        if "-lsb" in machine_name:
            #string = "Manifest link: "+repo_link+"/machines/"+manifest_img_type+"/core-image-sato-sdk-"+manifest_img_type+".manifest"
            string = "Manifest link: "+repo_link+"/machines/"+manifest_img_type+"-lsb/core-image-lsb-sdk-"+manifest_img_type+".manifest"
            print_lava(string)
            #os.system("wget -q "+repo_link+"/machines/"+manifest_img_type+"/core-image-sato-sdk-"+manifest_img_type+".manifest")
            os.system("wget -q "+repo_link+"/machines/"+manifest_img_type+"-lsb/core-image-lsb-sdk-"+manifest_img_type+".manifest")
            os.system("mkdir -p tmp/deploy/images/"+manifest_img_type)
            #result = os.system("mv core-image-sato-sdk-"+manifest_img_type+".manifest tmp/deploy/images/"+manifest_img_type)
            result = os.system("mv core-image-lsb-sdk-"+manifest_img_type+".manifest tmp/deploy/images/"+manifest_img_type)
            print_lava("Status: " + str(result))
        elif ('ptest' in machine_name):
            string = "Manifest link: "+repo_link+"/machines/genericx86-64/core-image-sato-sdk-genericx86-64.manifest"
            print_lava(string)
            os.system("wget -q "+repo_link+"/machines/genericx86-64/core-image-sato-sdk-genericx86-64.manifest")
            os.system("mkdir -p tmp/deploy/images/genericx86-64")
            result = os.system("mv core-image-sato-sdk-genericx86-64.manifest tmp/deploy/images/genericx86-64/")
            print_lava("Status: " + str(result))
        else:
            string = "Manifest link: "+repo_link+"/machines/"+manifest_img_type+"/core-image-sato-sdk-"+manifest_img_type+".manifest"
            print_lava(string)
            os.system("wget -q "+repo_link+"/machines/"+manifest_img_type+"/core-image-sato-sdk-"+manifest_img_type+".manifest")
            os.system("mkdir -p tmp/deploy/images/"+manifest_img_type)
            result = os.system("mv core-image-sato-sdk-"+manifest_img_type+".manifest tmp/deploy/images/"+manifest_img_type)
            print_lava("Status: " + str(result))

print_lava("Running the runtime tests...")
for configuration in configurations:
    test_image_type = str(test_image_types[0])
    if "-lsb" in machine_name:
        test_image_type = "core-image-lsb-sdk"
        #test_image_type = "core-image-sato-sdk"
    print_lava("Running tests...")
    bitbake(test_image_type+" -c testimage", ignore_status=True)

    if notifications.lower() != "no":
        #### Variables ####
        #results.log "1.8" "1.8_rc1" "Weekly" "29812e61736a95f1de64b3e9ebbb9c646ebd28dd" "master" "2015-05-15 11:39:23" "genericx86" "core-image-sato" "x86_64" "NUC"
        if ("1.7" in bundle_context):
            cr_version = "1.7"
            cr_branch = "dizzy"
        elif ("1.8" in bundle_context):
            cr_version = "1.8"
            cr_branch = "fido"
        elif ("1.9" in bundle_context):
            cr_version = "1.9"
            cr_branch = "master"
        elif ("2.0" in bundle_context):
            cr_version = "2.0"
            cr_branch = "master"            
        else:
            cr_version = "2.x"
            cr_branch = "master"

        cr_milestone = repo_link.split("/")[-1]
        if (cr_milestone == ""):
            cr_milestone = repo_link.split("/")[-2]
        cr_milestone = cr_milestone.replace("yocto-","")
        if ('rc' not in cr_milestone or 'M' not in cr_milestone):
            cr_milestone = "sanity"

        cr_date = time.strftime('%Y-%m-%d %H:%M:%S')
        
        cr_hw = None
        cr_target = machine_name
        if "_" not in cr_target:
            if "qemu" in cr_target:
                cr_hw = cr_target
            else:
                cr_hw = "nuc"
        else:
            cr_target = machine_name.rsplit("_",1)[0]
            cr_hw = machine_name.rsplit("_",1)[1]
        cr_arch = "x86"
        if "64" in cr_target:
            cr_arch = "x86_64"    
        #### Variables ####
        print_lava("Converting log file to lava bundle...")
        string = "python log2bundle.py %s %s %s %s %s %s %s %s" % (log_path, bundle_test_type, bundle_context, machine_name, bundle_testrun_type, bundle_commit, bundle_date, test_image_type) #machine_name or cr_target?
        print_lava(string)
        runCmd(string)
        print_lava("Updating results in Testopia...")
        runCmd("cp "+log_path+" results.log")
        string = "Running: python /lava_test/scripts/testopia/update_testopia.py update BSP/QEMU "+manifest_img_type+" "+get_branch()+" "+bundle_context+" "+bundle_commit+" "+bundle_date+" \'"+os_version+"\'"
        print_lava(string)
        runCmd("python /lava_test/scripts/testopia/update_testopia.py update BSP/QEMU "+manifest_img_type+" "+get_branch()+" "+bundle_context+" "+bundle_commit+" "+bundle_date+" \'"+os_version+"\'", ignore_status=True)
        
        ##### Lava custom reports ######
        if (machine_name != "ptest"):
            status = os.system("sudo scp results.log root@10.237.112.80:/root/scripts/CustomReports/")
            if status != 0:
                print_lava("Failed to upload results log to CustomReports!")
            else:
                string = "rsh root@10.237.112.80 python /root/scripts/CustomReports/add_testrun.py /root/scripts/CustomReports/results.log %s %s \"Full Pass\" %s %s \"%s\" %s %s %s %s" % (cr_version, cr_milestone, bundle_commit, cr_branch, cr_date, cr_target, test_image_type, cr_arch, cr_hw)
                print_lava(string)
                runCmd("rsh root@10.237.112.80 'python /root/scripts/CustomReports/add_testrun.py /root/scripts/CustomReports/results.log %s %s \"Full Pass\" %s %s \"%s\" %s %s %s %s" % (cr_version, cr_milestone, bundle_commit, cr_branch, cr_date, cr_target, test_image_type, cr_arch, cr_hw), ignore_status=True)
        ##### Lava custom reports ######
        if ("ptest" in test_suite):
            print_lava("Uploading ptest logs to lava...")
            ptest_results = os.path.join(os.path.dirname(os.path.abspath(log_path)), "results")
            for file in os.listdir(ptest_results):
                runCmd("python ptest2bundle.py "+os.path.join(str(ptest_results),str(file))+" %s %s %s %s %s " % (bundle_context, machine_name, bundle_commit, bundle_date, test_image_type))
                print_lava("Uploaded: %s" % str(file))
    print_lava("Tests on "+machine_name+" completed!")
