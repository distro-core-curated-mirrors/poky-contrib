
.. _sgi:

**************************
SGI IRIX Specific Services
**************************

The modules described in this chapter provide interfaces to features that are
unique to SGI's IRIX operating system (versions 4 and 5).


.. toctree::

   al.rst
   cd.rst
   fl.rst
   fm.rst
   gl.rst
   imgfile.rst
   jpeg.rst
