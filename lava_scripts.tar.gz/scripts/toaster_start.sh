#!/bin/bash


cd /work/weekly/toaster/poky
source /work/weekly/toaster/poky/oe-init-build-env
source /home/lava/env/bin/activate
#export WEB_PORT=7998
export CUSTOM_IMAGE=1
source /work/weekly/toaster/poky/bitbake/bin/toaster

while true; do
    echo "in loop"
    sleep 30
done

