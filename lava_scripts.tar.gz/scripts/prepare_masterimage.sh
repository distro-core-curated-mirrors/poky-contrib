#!/bin/bash

rm -rf /home/root/sources
mkdir -p /home/root/sources
cd /home/root/sources/
wget http://192.168.99.30/tmp/source_pkgs/core-image-sato-sdk-genericx86-64.tar.gz
wget http://192.168.99.30/tmp/source_pkgs/bzImage-genericx86-64.bin
wget http://192.168.99.30/tmp/source_pkgs/openssh-sftp-6.5p1-r0.core2_64.rpm
wget http://192.168.99.30/tmp/source_pkgs/openssh-sftp-server-6.5p1-r0.core2_64.rpm
cd ~
umount /boot
umount /mnt/testrootfs
umount /sys/firmware/efi/efivars
mount -L boot /boot
mkdir -p /mnt/testrootfs
mount -L testrootfs /mnt/testrootfs
modprobe efivarfs
mount -t efivarfs efivarfs /sys/firmware/efi/efivars
rm -f /boot/test-kernel
cp ~/sources/bzImage-genericx86-64.bin /boot/test-kernel
rm -rf /mnt/testrootfs/*
tar xf ~/sources/core-image-sato-sdk-genericx86-64.tar.gz -C /mnt/testrootfs
mkdir -p /mnt/testrootfs/home/root/.ssh
chmod 700 /mnt/testrootfs/home/root/.ssh
cp /home/root/.ssh/authorized_keys /mnt/testrootfs/home/root/
chmod 600 /mnt/testrootfs/home/root/authorized_keys
mkdir -p /mnt/testrootfs/home/root/sources
cp /home/root/sources/openssh-sftp*.rpm /mnt/testrootfs/home/root/sources/
cp /usr/lib/openssh/sftp-server /mnt/testrootfs/usr/lib/openssh/sftp-server
printf '\x07\x00\x00\x00\x74\x00\x65\x00\x73\x00\x74\x00\x00\x00' > /sys/firmware/efi/efivars/LoaderEntryOneShot-4a67b082-0a4c-41cf-b6c7-440b29bb8c4f
reboot

