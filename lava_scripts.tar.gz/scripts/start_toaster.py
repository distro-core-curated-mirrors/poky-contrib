#!/usr/bin/python
import pexpect,os,sys,time

COMMIT = str(sys.argv[1])
HOMEDIR = '/work/weekly/toaster/'
POKYDIR = HOMEDIR + 'poky/'
SOURCE = 'cd ' + POKYDIR + '; source oe-init-build-env'
COMMAND = '. ../bitbake/bin/toaster'

os.chdir(POKYDIR)

print "Trying to kill toaster"
KILL_COMMAND = "ps -ef | grep 'toaster'| grep -v grep | grep -v start_toaster | awk '{print $2}' | xargs kill;"
#print KILL_COMMAND
os.system(KILL_COMMAND)
#print "Trying to kill screen"
#KILL_SCREEN = "screen -ls | grep pts | cut -d. -f1 | awk '{print $1}' | xargs kill;"
#KILL_SCREEN = "ps -ef | grep tmux | grep -v grep | awk '{print $2}' | xargs kill;"
#os.system(KILL_SCREEN)
os.system("cd " + POKYDIR + "&& git checkout -f master && git pull && git checkout " + COMMIT)
print('Poky checked out at: ' + COMMIT)
print('Current directory: ')
os.system('pwd')
#os.system('script /dev/null')

child = pexpect.spawn('bash')
print 'bash spawned'
child.sendline('/lava_test/scripts/toaster_start.sh')
child.expect('in loop', timeout=300)
print 'toaster started'
child.sendcontrol('z')
child.sendline('bg')
child.expect('lava@lavaworker01')
child.sendline('disown -h %1')
print 'toaster disowned'
#child.sendline('')
#time.sleep(5)
#child.sendline('su - lava')
#time.sleep(5)
#child.sendline('source /home/lava/env/bin/activate')
#child.expect('(env)')
#print 'env sourced'
#child.sendline(SOURCE)
#child.expect('(env)')
#child.sendline(COMMAND)
#time.sleep(300)
#child.expect('(env)', timeout=360)
#print 'toaster started'
#child.sendcontrol('a')
#child.sendline('d')
#child.sendline('tmux detach')
#print 'beginning setup script'
#setup_command = 'export DISPLAY=:10 && python /lava_test/scripts/setup_toaster.py'
#os.system(setup_command)
#print 'finished setup'
#print 'beginning test'
#test_command = 'export DISPLAY=:10 && python /lava_test/toaster_tests/run_toastertests.py'
#os.system(test_command)
#print 'tests done'
#print 'run finished'
exit(0)
