#!/bin/bash

#ARGS[0] - commit
#ARGS[1] - date
#ARGS[2] - image type (genericx86)
#ARGS[3] - core type (core-image-sato-sdk)
#ARGS[4] - machine (minnowmax32)
#ARGS[5] - retest without cloning
#ARGS[6] - test suite (auto)
#ARGS[7] - notifications (yes)
#ARGS[8] - yocto-version (1.9)

ARGS=("$@")
if [ "$#" -lt 5 ]; then
    echo "Error: Please provide all required parameters."
    exit 1
fi

ARGS5=${ARGS[5]:-no}
ARGS6=${ARGS[6]:-auto}
ARGS7=${ARGS[7]:-yes}
ARGS8=${ARGS[8]:-master}

echo "Starting remote eclipse tests..."
rsh root@<vali-ip> 'python /home/valentin/eclipsetests/runEclipse.py '${ARGS1}' '${ARGS2}' '${ARGS3}' '${ARGS4}

# Get the log back
scp root@<vali-ip>:/home/valentin/eclipsetests/eclipselog.log .

echo "Converting log to lava bundle..."
python log2bundle.py eclipselog.log runtime $ARGS8 $ARGS[4] weekly ARGS[0] ARGS[1] ARGS[2]