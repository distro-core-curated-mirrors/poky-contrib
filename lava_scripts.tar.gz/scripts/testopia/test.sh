#!/bin/bash

product='Toaster'
poky_version='1.8_M2.RC2'
environment='Ubuntu 14.10 x86_64'
fp_date='2015-02-20'
branch='master'
commit='bf3b0601fa45b98ad33a2e4fd048f3616f50d8da'
targets='Backend UI'


set -e
set +e
export https_proxy='http://proxy-jf.intel.com:911/'

#printf "%s\n" "$product"
#printf "%s\n" "$poky_version"
#printf "%s\n" "$environment"
#printf "%s\n" "$fp_date"
#printf "%s\n" "$branch"
#printf "%s\n" "$commit"
#printf "%s\n" "$targets"

#printf "%s\n" "/lava_test/scripts/testopia/update_testopia.py create '$product' '$targets' '$branch' '$poky_version' '$commit' '$fp_date' '$environment'"

ut=$(/lava_test/scripts/testopia/update_testopia.py create "$product" "$targets" "$branch" "$poky_version" "$commit" "$fp_date" "$environment")

#printf "%s\n" "$ut"
#res=""
#echo "$ut"

#if echo "$ut" | grep -i "Error*"; then res="fail"; else res="pass"; fi
if echo "$ut" | grep -i "^Error*"; then res="fail"; else res="pass"; fi
echo "$res"
#lava-test-case $product --result $res
