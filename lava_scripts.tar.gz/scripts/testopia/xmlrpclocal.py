#!/usr/bin/python

#from testopia import Testopia
from testopia import *
import re
#t = Testopia('corneliux.stoicescu@intel.com', 'bugzilla', 'https://10.237.112.202/bugzilla/xmlrpc.cgi')
#t = Testopia('corneliux.stoicescu@intel.com', 'bugzilla', 'https://bugzilla.ctest.yoctodev.org/xmlrpc.cgi')
t = Testopia('ionutx.chisanovici@intel.com', 'thefatlady', 'https://bugzilla.ctest.yoctodev.org/xmlrpc.cgi')
#t = Testopia('ionutx.chisanovici@intel.com', 'thefatlady', 'https://bugzilla.yoctoproject.org/xmlrpc.cgi')
#tc = t.product_get_builds(60)
#for build in tc:
#    print build

#tc = t.product_get_environments(60)
#for build in tc:
#    print build

product = 'OE-Core'
branch = 'master'

tp = t.testplan_list(name=product+': '+branch+' branch')
product_id = tp[0]['product_id']
plan_id = tp[0]['plan_id']
print product_id, plan_id


#product = "OE-Core"
'''fp_date = "2015-02-20"
poky_commit = "bf3b0601fa45b98ad33a2e4fd048f3616f50d8da"
runs = t.testplan_get_test_runs(25)
builds = t.product_get_builds(60)
build_id = None
for build in builds:
    if re.match(r'^.*'+poky_commit, build['name']) and re.match(r'^'+fp_date, build['description']):
	build_id = build['build_id']

for run in runs:
    if re.match(r'^'+fp_date+' .*Weekly', run['summary']) and run['build_id'] == build_id:
    #if (run['summary'].startswith(str_name) and target in run['summary']):
	print run'''



#tc = t.testrun_get(3318)
#print tc
#print tc['summary']

#tcp = t.testplan_get_test_runs(25)
#tc = t.testrun_get_test_cases(878)
#{'build_id': 4, 'environment_id': 14, 'plan_id': 25, 'run_id': 3474, 'notes': '', 'product_version': 1.8, 'summary': 'TEMPLATE - 1.8 - Exploratory new test cases', 'manager_id': 694, 'plan_text_version': 2, 'start_date': '2015-02-10 10:12:24'}
#t.testcaserun_update(run_id=3391, case_id=1060, build_id=697, environment_id=140, case_run_status_id=2)

#for runs in tcp:
#    print runs

#for line in tc:
#    print line

#tp = t.testplan_get_test_runs(110)
#tp = t.testrun_get_test_cases(1592)
#for tc in tp:
    #print tc['case_id']

#t.testrun_create(build_id, env_id, plan_id, tr_summary, t.userId, product_version=yp_version)
#t.TestRun.create()
#cases_list = []
#for case in t.testrun_get_test_cases(3247):
#    cases_list.append(case['case_id'])
#t.testrun_add_cases(cases_list, 3391)
