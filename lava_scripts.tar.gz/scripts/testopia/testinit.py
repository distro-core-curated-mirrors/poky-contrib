#!/usr/bin/python

from testopia import *

class Test(Testopia):
    
    #def __init__(self):
	#self.test_test()

    def test_test(self):
	print "pass"

Test.test_test()