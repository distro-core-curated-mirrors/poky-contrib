#!/bin/bash

#ARGs[0] - poky commit

ARGS=("$@")
if [ "$#" -lt 1 ]; then
    echo "Error: Please provide all required parameters."
    exit 1
fi

#export DISPLAY=:10

su - lava -c 'python /lava_test/scripts/start_toaster.py '${ARGS[0]}
su - lava -c 'export DISPLAY=:10 && python /lava_test/scripts/setup_toaster.py'
su - lava -c 'export DISPLAY=:10 && python /lava_test/toaster_tests/run_toastertests.py'
