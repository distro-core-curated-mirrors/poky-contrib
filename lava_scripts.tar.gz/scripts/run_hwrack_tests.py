import os
import sys
import unittest
import logging
import time
import datetime
from time import gmtime, strftime

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'meta/lib')))

import oeqa.selftest
import oeqa.utils.ftools as ftools
from oeqa.utils.commands import Command, runCmd, get_bb_var, get_test_layer, bitbake
from oeqa.selftest.base import oeSelfTest


if (len(sys.argv)<7):
    print "Not enaugh arguments passed!"
    exit(1)

autoconf_file = os.path.join(os.environ['BUILDDIR'], 'conf', 'auto.conf')
required_packages = "rpm psplash"
test_image_types = ['core-image-sato-sdk']
repo_link = str(sys.argv[1]) #"http://autobuilder.yoctoproject.org/pub/releases/yocto-1.7.rc1" "yaml - repo_link"
bundle_context = repo_link.split("/")[-1]
if (bundle_context == ""):
    bundle_context="unknown"
bundle_test_type = str(sys.argv[2]) #"runtime" "yaml - test_type"
bundle_testrun_type = str(sys.argv[3]) #"weekly" "yaml - testrun_type"
bundle_commit = str(sys.argv[4]) #"8ac8eca2e3bd8c78e2b31ea974930ed0243258a3" "yaml - commit"
bundle_date = str(sys.argv[5]) #"2014-09-24" "yaml - date"
machine_name = str(sys.argv[6]) #yaml - target
test_suite = str(sys.argv[7]) #yaml - suite

if test_suite == "":
	test_suite = "auto"

os_version = "Ubuntu 14.10 x86_64"

def get_branch():
    branch = "master"
    if bundle_context != "unknown":
        if "1.5" in bundle_context:
            branch = "dora"
        if "1.6" in bundle_context:
            branch = "daisy"
        if "1.7" in bundle_context:
            branch = "dizzy"
        if "1.8" in bundle_context:
            branch = "fido"
        if "1.9" in bundle_context:
            branch = "master"
    return branch

def print_lava(string):
  os.system('echo '+string)


pw_control3 = '"'+str(os.path.join(os.environ['BUILDDIR'],'powercontrol3.exp'))+'"'
test_serial_control = '"'+str(os.path.join(os.environ['BUILDDIR'],'test-serialcontrol.exp'))


qemux86_conf = {
'qemux86':
"""
MACHINE = "qemux86"
INHERIT += "testimage"
TEST_SUITES_append = " auto"

""",
}

qemux86_64_conf = {
'qemux86-64':
"""
MACHINE = "qemux86-64"
INHERIT += "testimage"
TEST_SUITES_append = " auto"

""",
}

qemuarm_conf = {
'qemuarm':
"""
MACHINE = "qemuarm"
INHERIT += "testimage"
TEST_SUITES_append = " auto"

""",
}

qemumips_conf = {
'qemumips':
"""
MACHINE = "qemumips"
INHERIT += "testimage"
TEST_SUITES_append = " auto"

""",
}

qemuppc_conf = {
'qemuppc':
"""
MACHINE = "qemuppc"
INHERIT += "testimage"
TEST_SUITES_append = " auto"

""",
}

minnow_conf = {
'minnow':
"""
MACHINE = "minnow"
INHERIT += "testimage"
TEST_TARGET = "GummibootTarget"
TEST_TARGET_IP = "192.168.99.12"
TEST_POWERCONTROL_CMD = """+str(pw_control3)+"""
TEST_POWERCONTROL_EXTRA_ARGS = "test 10.237.112.97 minnow1 120"
IMAGE_FSTYPES_append = " tar.gz"
TEST_SUITES_append = " auto"

""",
}

genericx86_conf = {
'genericx86':
"""
MACHINE = "genericx86"
IMAGE_FSTYPES_append = " tar.gz"
INHERIT += "testimage"
TEST_TARGET = "GrubTarget"
TEST_TARGET_IP = "192.168.99.14"
TEST_POWERCONTROL_CMD = """+str(pw_control3)+"""
TEST_POWERCONTROL_EXTRA_ARGS = "test 10.237.112.97 atomd2600 120"
TEST_SERIALCONTROL_CMD = """+str(test_serial_control)+""" atomd2600"
INHERIT += "buildhistory"

TEST_SUITES = " """+str(test_suite)+""" "
""",
}

genericx86_64_sugarbay_conf = {
'genericx86-64_sugarbay':
"""
BB_NUMBER_THREADS ?= "16"
PARALLEL_MAKE ?= "-j 16"
MACHINE = "genericx86-64"
INHERIT += "testimage"
TEST_TARGET = "GrubTarget"
TEST_TARGET_IP = "10.237.112.97:2203"
TEST_POWERCONTROL_CMD = """+str(pw_control3)+"""
TEST_POWERCONTROL_EXTRA_ARGS = "test 10.237.112.97 sugarbay1 120"
IMAGE_FSTYPES_append = " tar.gz"
TEST_SERIALCONTROL_CMD = """+str(test_serial_control)+""" sugarbay1"
INHERIT += "buildhistory"

TEST_SUITES = " """+str(test_suite)+""" "
""",
}

ptest_conf = {
'ptest':
"""
BB_NUMBER_THREADS ?= "16"
PARALLEL_MAKE ?= "-j 16"
MACHINE = "genericx86-64"
INHERIT += "testimage"
TEST_TARGET = "GrubTarget"
TEST_TARGET_IP = "10.237.112.97:2203"
TEST_POWERCONTROL_CMD = """+str(pw_control3)+"""
TEST_POWERCONTROL_EXTRA_ARGS = "test 10.237.112.97 sugarbay1 120"
IMAGE_FSTYPES_append = " tar.gz"
TEST_SERIALCONTROL_CMD = """+str(test_serial_control)+""" sugarbay1"
INHERIT += "buildhistory"
IMAGE_FEATURES_append = " ptest-pkgs"
IMAGE_INSTALL_append = " ptest-runner"
TEST_SUITES = " """+str(test_suite)+""" "
""",
}

genericx86_64_nuc_conf = {
'genericx86-64_nuc':
"""
MACHINE = "genericx86-64"
INHERIT += "testimage"
TEST_TARGET = "GummibootTarget"
TEST_TARGET_IP = "10.237.112.97:2201"
TEST_POWERCONTROL_CMD = """+str(pw_control3)+"""
TEST_POWERCONTROL_EXTRA_ARGS = "test 10.237.112.97 nuc1 120"
IMAGE_FSTYPES_append = " tar.gz"
TEST_SUITES_append = " auto"

""",
}

beaglebone_black_conf = {
'beaglebone_black':
"""
MACHINE = "beaglebone"
INHERIT += "testimage"
TEST_TARGET = "BeagleBoneTarget"
TEST_TARGET_IP = "192.168.99.15"
TEST_POWERCONTROL_CMD = """+str(pw_control3)+"""
TEST_POWERCONTROL_EXTRA_ARGS = "test 10.237.112.97 beaglebone1 240"
TEST_SERIALCONTROL_CMD = """+str(test_serial_control)+""" beaglebone1"
#TEST_SUITES_append = " auto"

""",
}

edgerouter_conf = {
'edgerouter':
"""
MACHINE = "edgerouter"
INHERIT += "testimage"
TEST_TARGET = "EdgeRouterTarget"
TEST_TARGET_IP = "10.237.112.97:2208"
TEST_POWERCONTROL_CMD = """+str(pw_control3)+"""
TEST_POWERCONTROL_EXTRA_ARGS = "test 10.237.112.97 edgerouter1 120"
TEST_SERIALCONTROL_CMD = """+str(test_serial_control)+""" edgerouter1"
TEST_SUITES_append = " auto"

""",
}

############## meta-intel ####################

core2_32_conf = {
'intel-core2-32':
"""
MACHINE = "intel-core2-32"
IMAGE_FSTYPES_append = " tar.gz"
INHERIT += "testimage"
TEST_TARGET = "GrubTarget"
TEST_TARGET_IP = "192.168.99.14"
TEST_POWERCONTROL_CMD = """+str(pw_control3)+"""
TEST_POWERCONTROL_EXTRA_ARGS = "test 10.237.112.97 atomd2600 120"
TEST_SERIALCONTROL_CMD = """+str(test_serial_control)+""" atomd2600"
TEST_SUITES_append = " auto"

""",
}

corei7_64_conf = {
'intel-corei7-64':
"""
MACHINE = "intel-corei7-64"
INHERIT += "testimage"
TEST_TARGET = "GrubTarget"
TEST_TARGET_IP = "192.168.99.13"
TEST_POWERCONTROL_CMD = """+str(pw_control3)+"""
TEST_POWERCONTROL_EXTRA_ARGS = "test 10.237.112.97 sugarbay1 120"
IMAGE_FSTYPES_append = " tar.gz"
TEST_SERIALCONTROL_CMD = """+str(test_serial_control)+""" sugarbay1"
TEST_SUITES_append = " auto"

""",
}

nuc_conf = {
'nuc':
"""
MACHINE = "nuc"
INHERIT += "testimage"
TEST_TARGET = "GummibootTarget"
TEST_TARGET_IP = "10.237.112.97:2201"
TEST_POWERCONTROL_CMD = """+str(pw_control3)+"""
TEST_POWERCONTROL_EXTRA_ARGS = "test 10.237.112.97 nuc1 120"
IMAGE_FSTYPES_append = " tar.gz"
TEST_SUITES_append = " auto"

""",
}

sugarbay_conf = {
'sugarbay':
"""
MACHINE = "sugarbay"
INHERIT += "testimage"
TEST_TARGET = "GrubTarget"
TEST_TARGET_IP = "10.237.112.97:2203"
TEST_POWERCONTROL_CMD = """+str(pw_control3)+"""
TEST_POWERCONTROL_EXTRA_ARGS = "test 10.237.112.97 sugarbay1 120"
IMAGE_FSTYPES_append = " tar.gz"
TEST_SERIALCONTROL_CMD = """+str(test_serial_control)+""" sugarbay1"
INHERIT += "buildhistory"

TEST_SUITES = " """+str(test_suite)+""" "
""",
}

configurations = genericx86_conf

if (machine_name == "minnowboard" or machine_name == "minnow"):
    print "Running only the minnnowboard..."
    configurations = minnow_conf
    log_path = "tmp/work/minnow-poky-linux/core-image-sato-sdk/1.0-r0/core-image-sato-sdk-1.0/results-bitbake-worker.log"

if (machine_name == "genericx86" or machine_name == "generic_x86"):
    print "Running only the genericx86..."
    configurations = genericx86_conf
    log_path = "tmp/work/genericx86-poky-linux/core-image-sato-sdk/1.0-r0/core-image-sato-sdk-1.0/results-bitbake-worker.log"

if (machine_name == "generic_x86_64_sugarbay" or machine_name == "genericx86-64"):
    print "Running only the generic x86_64 on sugarbay..."
    configurations = genericx86_64_sugarbay_conf
    log_path = "tmp/work/genericx86_64-poky-linux/core-image-sato-sdk/1.0-r0/core-image-sato-sdk-1.0/results-bitbake-worker.log"

if (machine_name == "ptest"):
    print "Running only the ptest on sugarbay..."
    configurations = ptest_conf
    required_packages +=" ptest-runner"
    log_path = "tmp/work/genericx86_64-poky-linux/core-image-sato-sdk/1.0-r0/core-image-sato-sdk-1.0/results-bitbake-worker.log"

if (machine_name == "generic_x86_64_nuc"):
    print "Running only the generic x86_64 on NUC..."
    configurations = genericx86_64_nuc_conf
    log_path = "tmp/work/genericx86_64-poky-linux/core-image-sato-sdk/1.0-r0/core-image-sato-sdk-1.0/results-bitbake-worker.log"

if (machine_name == "beagleboneblack"):
    print "Running only the beaglebone black..."
    configurations = beaglebone_black_conf
    log_path = "tmp/work/beaglebone-poky-linux-gnueabi/core-image-sato-sdk/1.0-r0/core-image-sato-sdk-1.0/results-bitbake-worker.log"    

if (machine_name == "edgerouter"):
    print "Running only the edge router..."
    configurations = edgerouter_conf
    log_path = "tmp/work/edgerouter-poky-linux/core-image-sato-sdk/1.0-r0/core-image-sato-sdk-1.0/results-bitbake-worker.log"

if (machine_name == "qemux86"):
    print "Running only the qemux86..."
    configurations = qemux86_conf
    log_path = "tmp/work/qemux86-poky-linux/core-image-sato-sdk/1.0-r0/core-image-sato-sdk-1.0/results-bitbake-worker.log"

if (machine_name == "qemux86_64"):
    print "Running only the qemux86-64..."
    configurations = qemux86_64_conf
    log_path = "tmp/work/qemux86_64-poky-linux/core-image-sato-sdk/1.0-r0/core-image-sato-sdk-1.0/results-bitbake-worker.log"

if (machine_name == "qemuarm"):
    print "Running only the qemuarm..."
    configurations = qemuarm_conf
    log_path = "tmp/work/qemuarm-poky-linux-gnueabi/core-image-sato-sdk/1.0-r0/core-image-sato-sdk-1.0/results-bitbake-worker.log"

if (machine_name == "qemumips"):
    print "Running only the qemumips..."
    configurations = qemumips_conf
    log_path = "tmp/work/qemumips-poky-linux/core-image-sato-sdk/1.0-r0/core-image-sato-sdk-1.0/results-bitbake-worker.log"

if (machine_name == "qemuppc"):
    print "Running only the qemuppc..."
    configurations = qemuppc_conf
    log_path = "tmp/work/qemuppc-poky-linux/core-image-sato-sdk/1.0-r0/core-image-sato-sdk-1.0/results-bitbake-worker.log"

############## meta intel conf ###############

if (machine_name == "sugarbay"):
    print "Running only the meta-intel sugarbay..."
    configurations = sugarbay_conf
    log_path = "tmp/work/sugarbay-poky-linux/core-image-sato-sdk/1.0-r0/core-image-sato-sdk-1.0/results-bitbake-worker.log"

if (machine_name == "nuc"):
    print "Running only the meta-intel nuc..."
    configurations = nuc_conf
    log_path = "tmp/work/nuc-poky-linux/core-image-sato-sdk/1.0-r0/core-image-sato-sdk-1.0/results-bitbake-worker.log"

if (machine_name == "core2_32"):
    print "Running only the meta-intel core2 32..."
    configurations = core2_32_conf
    log_path = "tmp/work/intel_core2_32-poky-linux/core-image-sato-sdk/1.0-r0/core-image-sato-sdk-1.0/results-bitbake-worker.log"

if (machine_name == "corei7_64"):
    print "Running only the meta-intel corei7 64..."
    configurations = corei7_64_conf
    log_path = "tmp/work/intel_corei7_64-poky-linux/core-image-sato-sdk/1.0-r0/core-image-sato-sdk-1.0/results-bitbake-worker.log"    


print "Running smoke test on configurations.."
for configuration in configurations:
    print "Configuration: " + configuration
    result = bitbake('-p', postconfig=configurations[configuration], ignore_status=True)
    print "Status: " + str(result.status)
    if ("qemu" in machine_name):
        result = os.system("ps ax | grep Xtightvnc | grep -v grep")
        if (result != 0):
            print_lava("VNC server not started. Trying to start...")
            res = os.system("vncserver")
            if (res != 0):
                print_lava("Warning: May not have started vnc server!")    


print "Building packages for each configuration:"
for configuration in configurations:
    print "Configuration: " + configuration
    result = bitbake(required_packages, postconfig=configurations[configuration], ignore_status=True)
    print "Status: " + str(result.status)

print "Running the runtime tests for each configuration:"
for configuration in configurations:
    for image_type in test_image_types:
	if ("--retest" not in str(sys.argv)):
            runtest_cmd = "test-remote-image --image-types %s --repo-link  %s --required-packages %s" % (image_type, repo_link, required_packages)
	else:
	    print "Retesting images..."
            runtest_cmd = "test-remote-image --skip-download --image-types %s --repo-link  %s --required-packages %s" % (image_type, repo_link, required_packages)
	print "######################"
	print "Configuration: " + configuration+ " ("+time.strftime("%H:%M:%S", gmtime())+")" 
	ftools.write_file(autoconf_file, configurations[configuration])
	print "Image type: " + image_type
	result = runCmd(runtest_cmd, ignore_status=True)
	print "Status: " + str(result.status)
	# Should get date from bitbake somehow?
	print "Writing logfile "+ " ("+time.strftime("%H:%M:%S", gmtime())+")"
	logfile = "%s-%s-%s.log" % (configuration, image_type, datetime.datetime.now().strftime("%Y%m%d%H%M%S%f"))
	logpath = os.path.join(os.environ['BUILDDIR'], logfile)
	ftools.write_file(logpath, result.output)
    print "Converting log file to lava bundle..."
#    runCmd("python log2bundle.py results-bitbake-worker.log runtime yocto-1.7.rc1 nuc weekly 8ac8eca2e3bd8c78e2b31ea974930ed0243258a3 2014-09-24 core-image-sato-sdk", ignore_status=True)
    test_image_type = str(test_image_types[0])
    runCmd("python log2bundle.py %s %s %s %s %s %s %s %s " % (log_path, bundle_test_type, bundle_context, machine_name, bundle_testrun_type, bundle_commit, bundle_date, test_image_type))
    if ("ptest" in test_suite):
        print "Uploading ptest logs to lava..."
        ptest_results = os.path.join(os.path.dirname(os.path.abspath(log_path)), "results")
        for file in os.listdir(ptest_results):
            runCmd("python ptest2bundle.py "+os.path.join(str(ptest_results),str(file))+" %s %s %s %s %s " % (bundle_context, machine_name, bundle_commit, bundle_date, test_image_type))
            print "Uploaded: %s" % str(file)

    print "Updating results in Testopia..."
    try:
        manifest_img_type = configuration.replace('_nuc','')
        manifest_img_type = manifest_img_type.replace('_sugarbay','')        
        runCmd("cp "+log_path+" results.log")
        print_lava("python /lava_test/scripts/testopia/update_testopia.py update BSP/QEMU "+manifest_img_type+" "+get_branch()+" "+bundle_context+" "+bundle_commit+" "+bundle_date+" \'"+os_version+"\'")
        try:
            status = runCmd("python /lava_test/scripts/testopia/update_testopia.py update BSP/QEMU "+manifest_img_type+" "+get_branch()+" "+bundle_context+" "+bundle_commit+" "+bundle_date+" \'"+os_version+"\'", ignore_status=True)
        except:
            pass
        if status == 0:
            break
    except:
        print_lava("Error updating Testopia!")
        pass

    print "Tests on "+machine_name+" completed!"
