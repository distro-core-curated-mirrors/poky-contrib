#!/usr/bin/python

import sys
import os
import time
from time import gmtime, strftime
import datetime
from uuid import uuid4
import requests
import subprocess

try:
  target = str(sys.argv[1])
  commit = str(sys.argv[2])
  date = str(sys.argv[3])
except IndexError, NameError:
    print "Usage: ab2lava <os> <commit> <date> \n Example: ab2lava fedora 9aff3a4ec058a1a1149d026ebedcc6251089fffb 2015-01-06"
    exit(1)

targets = ["ubuntu","fedora","opensuse","centos"]
build_set = ['nightly-world', 'buildtools', 'nightly-arm', 'nightly-mips', 'nightly-multilib', 'nightly-x32', \
 'nightly-x86-64', 'nightly-x86-64-lsb', 'nightly-x86', 'nightly-rpm', 'poky-tiny', 'nightly-qa-systemd', 'nightly-qa-extras',\
  'nightly-qa-targetbuilds', 'nightly-qa-logrotate', 'nightly-qa-pam', 'nightly-qa-skeleton']

if target not in targets:
    print "Wrong os name. Supported os names are:"+str(targets)
    exit(1)

if target == "ubuntu":
    target_ip = "10.237.112.121"
if target == "fedora":
    target_ip = "10.237.112.122"
if target == "opensuse":
    target_ip = "10.237.112.141"
if target == "centos":
    target_ip = "10.237.112.142"

def getBuildStatus(build_type):
    correct_commit = 0
    status = "fail"
    reason = ""      
    builders_url = "http://"+target_ip+":8010/json/builders/"+build_type+"/builds?select=-1&as_text=1"
    page = requests.get(builders_url)
    builds = page.text.encode('ascii','ignore')
    content = builds.splitlines()
    #check if build has the correct commit
    for i in xrange(len(content)):
        if commit in content[i]:
          correct_commit = 1
    if correct_commit == 1:
      #read only the last 15 lines block
      for i in xrange(len(content)-15, len(content)):
          if '\"text\":' in content[i]:
              if '\"build\",' in content[i+1]:
                  status = content[i+2].replace(" ", "")[1:-1]
                  if status == "successful":
                      status = "pass"
              elif '\"failed\"' in content[i+1]:
                  status = "fail"
                  j = i+2
                  while "]" not in content[j]:
                      reason += content[j].split('\"')[1]
                      reason += ", "
                      j += 1
                  if (reason != ""):
                      reason = reason[:-2]
    else:
        status = "fail"
        reason = "Commit not found"
    return (status, reason)

# build the results section of the bundle

test_list = []
test_list_string = ""

for i in xrange(len(build_set)):
    (result, msg) = getBuildStatus(build_set[i])
    test_id = build_set[i]
    test_template = """    {
          "result": "%s",
          "test_case_id": "%s",
          "message": "%s"
        },
  """ % (result, test_id, msg)
    test_list.append(test_template)

for i in xrange(len(test_list)):
    test_list_string += test_list[i]

#delete the last comma or else lava will not display the bundle
test_list_string = test_list_string[:test_list_string.rfind(',')]


# complete the rest of the bundle stream
year = time.strftime("%Y-%m-%e", gmtime())
hour = time.strftime("%H:%M:%S", gmtime())
uid = str(uuid4())

json = """{
 "test_runs": [
    {
    "software_context": {
        "image": {
          "name": "Distro Testing %s"
        }
    },
    "test_results": [
        %s
      ],
      "attributes": {
        "commit": "%s",
        "date": "%s"
      },
      "analyzer_assigned_uuid": "%s",
      "analyzer_assigned_date": "%sT%sZ",
      "test_id": "Distro Testing %s",
      "time_check_performed": false
    }],
  "format": "Dashboard Bundle Format 1.7"
}""" % (target.capitalize(), test_list_string ,commit ,date, uid, year, hour, target.capitalize())

#print json

bundlename = "distro_"+target+"_"+datetime.datetime.now().strftime("%Y%m%d%H%M%S%f")+".bundle"
with open(bundlename, 'w') as the_file:
    the_file.write(json)

transfer_file = subprocess.check_output("sudo scp "+bundlename+" root@192.168.99.30:/var/lib/lava/dispatcher/tmp/bundle_streams/autobuilder", shell=True)
print transfer_file
submit_file = subprocess.check_output("sudo ssh root@192.168.99.30 \"cd /var/lib/lava/dispatcher/tmp/bundle_streams/autobuilder && lava-tool put --dashboard-url=http://localhost/RPC2/ "+bundlename+" /anonymous/distro-"+target+"/\"", shell=True)
print submit_file

os.remove(bundlename)