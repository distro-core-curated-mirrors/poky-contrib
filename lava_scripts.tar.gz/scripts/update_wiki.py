#!/usr/bin/python

from simplemediawiki import MediaWiki
import os, sys, re
import datetime
from testopia import Testopia
from difflib import SequenceMatcher as SM

def get_workweek():
    now = datetime.datetime.now()
    return datetime.date(now.year, now.month, now.day).isocalendar()[1]

try:
    branch = str(sys.argv[1]).strip()
    poky_version = str(sys.argv[2]).strip()
    poky_commit = str(sys.argv[3]).strip()
    ab_link = str(sys.argv[4]).strip()
    date = str(sys.argv[5]).strip()
except IndexError, NameError:
    print "Usage: ./update_wiki.py <branch> <version> <commit> <download_link> <date>"
    print "Example: ./update_wiki.py master 1.8_M4.rc2 33558eacc8a2d3dce3396b9ab2fd0773ac5076bc http://autobuilder.yoctoproject.org/pub/releases/yocto-1.8_M4.rc2/ 2015-04-03"
    exit(1)

poky_version = poky_version.replace("yocto-","")
#++++++++++++++++++++
#   Get testruns    +
#++++++++++++++++++++

t = Testopia('ionutx.chisanovici@intel.com', 'thefatlady', 'https://bugzilla.yoctoproject.org/xmlrpc.cgi')

products = {'fedora':[],
'ubuntu':[],
'centos':[],
'opensuse':[],
'Edgerouter':[],
'GenericX86':[],
'GenericX86_64':[],
'qemux86':[],
'qemuarm':[],
'qemumips':[],
'qemuppc':[],
'qemux86_64':[],
'Eclipse Plugin':[],
'Meta-yocto':[],
'Hob':[],
'Toaster':[],
'OE-Core':[],
'BitBake':[],
'Runtime':[]
}

product_environments = {'GenericX86_64':'genericx86-64 on NUC',
                'GenericX86':'generic-x86 on AtomPC',
                'qemux86':'qemu-x86',
                'qemux86_64':'qemux86-64',
                'qemuarm':'qemuarm',
                'qemumips':'qemumips',
                'qemuppc':'qemuppc',
                'Hob':'Ubuntu 14.10 x86_64',
                'BitBake':'Ubuntu 14.10 x86_64',
                'Runtime':'Multiple Environments',
                'OE-Core':'Ubuntu 14.10 x86_64',
                'Meta-yocto':'Ubuntu 14.04 x86_64',
                'Kepler':'Ubuntu 14.10 x86_64',
                'Toaster Backend':'Ubuntu 14.10 x86_64',
                "Toaster UI":"Ubuntu 14.10 x86_64",
                "Edgerouter":"EdgeRouter",
}

def get_environment(product):
    for environment in product_environments:
        if environment == product:
            return product_environments[environment]
        elif "fedora" in product:
            return "Fedora 21 x86_64"
        elif "ubuntu" in product:
            return "Ubuntu 14.10 x86_64"
        elif "centos" in product:
            return "CentOS 7 x86_64"
        elif "opensuse" in product:
            return "OpenSuse 13.2 x86_64"     
    return "Ubuntu 14.10 x86_64"                           

def get_product_id(product, branch):
    found = 0
    tp = t.testplan_list(name=product+': '+branch+' branch')
    if tp != []:
        product_id = tp[0]['product_id']
        return product_id
    else:
        tp = t.testplan_list(name=product+': '+str(branch).lower()+' branch')
        if tp != []:
            product_id = tp[0]['product_id']
            return product_id
        else:
            if ('fedora' in product or 'ubuntu' in product or 'centos' in product or 'opensuse' in product):
                tp = t.testplan_list(name="Automated Build Testing"+': '+str(branch).lower()+' branch')
            else:
                tp = t.testplan_list(name="BSP/QEMU"+': '+str(branch).lower()+' branch')
            if tp != []:
                product_id = tp[0]['product_id']
                return product_id
            else:            
                print "Cannot find product!"
                exit(1)

def get_plan_id(product, branch):
    tp = t.testplan_list(name=product+': '+branch+' branch')
    if tp != []:
        plan_id = tp[0]['plan_id']    
        return plan_id
    else:
        if ('fedora' in product or 'ubuntu' in product or 'centos' in product or 'opensuse' in product):
            tp = t.testplan_list(name="Automated Build Testing"+': '+branch+' branch')
            plan_id = tp[0]['plan_id']
        else:
            tp = t.testplan_list(name="BSP/QEMU"+': '+branch+' branch')
            plan_id = tp[0]['plan_id']
        return plan_id

def get_env_id(product_id, env):
    tp_envs = t.product_get_environments(product_id)
    for envs in tp_envs:
        if env == str(envs['name']):
            return envs['environment_id']

def get_build_id(product_id, poky_version, poky_commit, fp_date):
    tp_builds = t.product_get_builds(product_id)
    found = 0
    for build in tp_builds:
        if ((poky_version+": "+poky_commit == str(build['name'])) and (fp_date == str(build['description']))):
            found = 1
            return build['build_id']
    if (found == 0):
        print "Cannot find the build id. Trying to find the closest match..."
        baseline = 0.75
        guess = ""
        for build in tp_builds:
            if SM(None, poky_version+": "+poky_commit, str(build['name'])).ratio() > baseline:
                guess = build['build_id']
                baseline = SM(None, poky_version+": "+poky_commit, str(build['name'])).ratio()
                found = 1
        if (found == 1):
            print "A close match found:"
            print str(guess)
            return guess
        else:
            print "Cannot find a close match!"

def get_run_ids(plan_id, summary, build_id, env_id):
    plan = t.testplan_get_test_runs(plan_id)
    run_ids = []
    if (not build_id and not env_id):
        for run in plan:
            if re.match(r''+summary+'', run['summary']):
                run_ids.append(run['run_id'])
    else:
        for run in plan:
            if (re.match(r''+summary+'', run['summary']) and (build_id == run['build_id']) and (env_id == run['environment_id'])):
                run_ids.append(run['run_id'])
    return run_ids

#product = "Meta-yocto"
#summary = '^'+date
#print get_plan_id(product,branch)
#print get_product_id(product, branch)
#print get_environment(product)
#print get_build_id(get_product_id(product, branch), poky_version, poky_commit, date)
#print get_env_id(get_product_id(product, branch),get_environment(product))
#print get_run_ids(get_plan_id(product,branch), summary, get_build_id(get_product_id(product, branch), poky_version, poky_commit, date), get_env_id(get_product_id(product, branch),get_environment(product)))

for product in products:
    try:        
        summary = '^'+date
        products[product] = get_run_ids(get_plan_id(product,branch), summary, get_build_id(get_product_id(product, branch), poky_version, poky_commit, date), get_env_id(get_product_id(product, branch),get_environment(product)))
    except:
        pass

#++++++++++++++++++++++++++
#   Fill wiki template    +
#++++++++++++++++++++++++++

#wiki = MediaWiki('https://wiki.ctest.yoctodev.org/w/api.php') # Test wiki
wiki = MediaWiki('https://wiki.yoctoproject.org/wiki/api.php') # Real wiki

if os.path.isfile("wikitemplate.txt"):
    with open("wikitemplate.txt", "r") as txtfile:
        content = txtfile.read()

content = content.replace("<<branch>>",branch)
content = content.replace("<<build_name>>",poky_version)
content = content.replace("<<commit>>",poky_commit)
content = content.replace("<<ab_link>>",ab_link)

header_vars = ""
for i in products:
    header_vars += "{{#vardefine:"+str(i).lower()+"|    "+str(products[i])+"    }}\n"
header_vars = header_vars.replace(",",", ")
header_vars = header_vars.replace("[","")
header_vars = header_vars.replace("]","")

header_template = "{| \n\
%s \
|}\n" % header_vars

content = header_template + content

now = datetime.datetime.now()
if len(str(now.month))<2:
    month = "0"+str(now.month)
else:
    month = str(now.month)
if len(str(now.day))<2:
    day = "0"+str(now.day)
else:
    day = str(now.day)

page_name = "WW"+str(get_workweek())+"_"+str(now.year)+"-"+month+"-"+day+"_FullPass_"+poky_version+"_"+poky_commit

#loginData = wiki.call({'action':'login', 'lgname':'MichaelHalstead','lgpassword':'wiki1999'})
loginData = wiki.call({'action':'login', 'lgname':'Lucian Musat','lgpassword':'wiki1999'}) # For real wiki

#personalLoginData = wiki.call({'action':'login', 'lgname':'MichaelHalstead','lgpassword':'wiki1999','lgtoken': loginData['login']['token']})
personalLoginData = wiki.call({'action':'login', 'lgname':'Lucian Musat','lgpassword':'wiki1999','lgtoken': loginData['login']['token']})

returnData = wiki.call({'action':'query','prop':'info', 'titles':page_name,'intoken':'edit'})

edittoken_key = returnData['query']['pages'].keys()[0]
edittoken = returnData['query']['pages'][edittoken_key]['edittoken']

results = wiki.call({'action': 'edit','title': page_name,'text': content,'token': edittoken})
if results['edit']['result'] == "Success":
    #print "Page created: https://wiki.ctest.yoctodev.org/wiki/"+page_name
    print "Page created: https://wiki.yoctoproject.org/wiki/"+page_name
else:
    print "Failed to create wiki page for "+poky_version
    exit(1)

#+++++++++++++++++++++++++++
#   Edit QA Run History    +
#+++++++++++++++++++++++++++

#content = '[https://wiki.ctest.yoctodev.org/wiki/'+page_name+' Full Pass for '+poky_version+' ('+date+')]<br />'
content = '[https://wiki.yoctoproject.org/wiki/'+page_name+' Full Pass for '+poky_version+' ('+date+')]<br />'

results = wiki.call({'action': 'edit','title': 'QA run history','prependtext': content,'token': edittoken})
if results['edit']['result'] == "Success":
    print "QA Run History updated!"
else:
    print "Failed to modify QA Run History!"
    exit(1)
