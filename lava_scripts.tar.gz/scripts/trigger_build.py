#!/usr/bin/python

import urllib2
import urllib
import cookielib
import sys

try:
    target = str(sys.argv[1])		#name of the ab machine, like: ubuntu or centos
    buildset = str(sys.argv[2])		#name of the buildset you want to trigger, like: nightly-x86 or nightly-qa-distro
    branch = str(sys.argv[3])		#branch, like: dizzy or dora
    poky_commit = str(sys.argv[4])	#poky commit
    qt3_commit = str(sys.argv[5])	#qt3_commit
    fp_date = str(sys.argv[6])		#date of the FP
except IndexError, NameError:
    print "Usage: trigger_build.py <target> <buildset> <branch> <poky_commit> <qt3_commit> <fp_date>\n Example: trigger_build.py fedora nightly-qa-distro master 9aff3a4ec058a1a1149d026ebedcc6251089fffb 6dd21a9f152a93e2df1178d7a5bd903d7edcf4be 2015-01-06"
    exit(1)

targets = ["ubuntu","fedora","opensuse","centos"]

if target not in targets:
    print "Wrong target name. Supported target names are:"+str(targets)
    exit(1)

if target == "ubuntu":
    target_ip = "10.237.112.85"
if target == "fedora":
    target_ip = "10.237.112.86"
if target == "opensuse":
    target_ip = "10.237.112.87"
if target == "centos":
    target_ip = "10.237.112.88"

if (buildset == "nightly-wic" and target != "ubuntu"):
    print("Skipping this distribution: %s" % target)
else:
    base_url = 'http://'+target_ip+':8010'
    login_action = '/login'
    builder_url = '/builders/'+buildset+'/force'
    cookie_file = './cookies/'+buildset+'.cookies'

    cj = cookielib.MozillaCookieJar(cookie_file)
    opener = urllib2.build_opener(
         urllib2.HTTPRedirectHandler(),
         urllib2.HTTPHandler(debuglevel=0),
         urllib2.HTTPSHandler(debuglevel=0),
         urllib2.HTTPCookieProcessor(cj)
    )
    opener.addheaders = [('User-agent',
        ('Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_7) '
         'AppleWebKit/535.1 (KHTML, like Gecko) '
         'Chrome/13.0.782.13 Safari/535.1'))]
    login_data = urllib.urlencode({
        'username' : 'autobuilder',
        'passwd' : 'qwe123'
    })
    login_url = base_url + login_action
    response = opener.open(login_url, login_data)
    cj.save()

    page_data = urllib.urlencode({
        'forcescheduler': buildset,
        'reason': '',
        'custom_fp_date': fp_date,
        'repo_poky': 'git://git.yoctoproject.org/poky',
        'branch_poky': branch,
        'commit_poky': poky_commit,
        'repo_meta-qt3': 'git://git.yoctoproject.org/meta-qt3',
        'branch_meta-qt3': branch,
        'commit_meta-qt3': qt3_commit
    })
    url = base_url + builder_url
    print url
    response = opener.open(url, page_data)
    cj.save()
